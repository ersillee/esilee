<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Log</title>
    <style>
        /* Styling seperti sebelumnya */
    </style>
</head>
<body>
    <h1 style="text-align: center;">Tambah Log</h1>
    <form action="/logs/store" method="post">
        <table>
            <tr>
                <td><label for="user_id">User ID:</label></td>
                <td><input type="number" name="user_id" id="user_id" required></td>
            </tr>
            <tr>
                <td><label for="action">Aksi:</label></td>
                <td><input type="text" name="action" id="action" required></td>
            </tr>
            <tr>
                <td><label for="table_name">Nama Tabel:</label></td>
                <td><input type="text" name="table_name" id="table_name" required></td>
            </tr>
            <tr>
                <td><label for="transaction_id">ID Catatan:</label></td>
                <td><input type="number" name="transaction_id" id="transaction_id" required></td>
            </tr>
            <tr>
                <td colspan="2" class="center">
                    <button type="submit">Tambah</button>
                </td>
            </tr>
        </table>
    </form>
    <div class="center">
        <a href="/logs">Kembali</a>
    </div>
</body>
</html>
