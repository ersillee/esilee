<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Tambah Pengeluaran Beasiswa</h2>
    <form action="/beasiswa/store" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
        </div>
        <div class="form-group">
            <label for="nama_siswa">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" required>
        </div>
        <div class="form-group">
            <label for="nama_siswa">Nama Siswa</label>
            <input type="text" class="form-control" id="nama_siswa" name="nama_siswa" required>
        </div>
        <div class="form-group">
            <label for="jenis_beasiswa">Jenis Beasiswa</label>
            <select class="form-control" id="jenis_beasiswa" name="jenis_beasiswa" required>
                <option value="Beasiswa Akademik">Beasiswa Akademik</option>
                <option value="Beasiswa Prestasi">Beasiswa Prestasi</option>
                <option value="Beasiswa Sosial">Beasiswa Sosial</option>
                <option value="Beasiswa Olahraga">Beasiswa Olahraga</option>
            </select>
        </div>
        <div class="form-group">
            <label for="jumlah_beasiswa">Jumlah Beasiswa</label>
            <input type="number" class="form-control" id="jumlah_beasiswa" name="jumlah_beasiswa" required>
        </div>
        <button type="submit" class="btn btn-primary">Simpan</button>
    </form>
</div>
<?= $this->endSection() ?>
