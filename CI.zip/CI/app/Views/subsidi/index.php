<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Daftar Subsidi</h2>
    <div class="alert alert-info">
        Total Pemasukan Bulan Ini: <?= number_format($total_pemasukan, 2, ',', '.') ?> 
    </div>
    <a href="/subsidi/create" class="btn btn-primary mb-3">Tambah Subsidi</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Jumlah Subsidi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($subsidi as $s): ?>
                <tr>
                    <td><?= $s['tanggal'] ?></td>
                    <td><?= $s['nama'] ?></td>
                    <td><?= $s['jumlah_subsidi'] ?></td>
                    <td>
                        <a href="/subsidi/edit/<?= $s['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="/subsidi/delete/<?= $s['id'] ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
