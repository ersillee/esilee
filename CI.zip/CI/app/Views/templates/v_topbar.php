<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-dark bg-primary topbar mb-4 static-top shadow">

            <!-- Sidebar Toggle (Topbar) -->
            <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                <i class="fa fa-bars"></i>
            </button>

            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto d-flex align-items-center">

                <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                <li class="nav-item dropdown no-arrow d-sm-none">
                    <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-search fa-fw"></i>
                    </a>
                </li>

                <!-- Nav Item - Account Dropdown (Admin Only) -->
                <?php if ($role == 'admin'): ?>
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="accountDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="mr-2 d-none d-lg-inline text-white small"><?= ucfirst($role) ?> Account</span>
                        <i class="fas fa-cog text-white"></i>
                    </a>
                    <!-- Dropdown - Account Menu -->
                    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="accountDropdown">
                        <a class="dropdown-item" href="/register">
                            <i class="fas fa-user-plus fa-sm fa-fw mr-2 text-gray-400"></i> Add Account
                        </a>
                        <a class="dropdown-item" href="/admin/list_account">
                            <i class="fas fa-user-edit fa-sm fa-fw mr-2 text-gray-400"></i> Daftar Account
                        </a>
                    </div>
                </li>
                <li class="nav-item">
                    <button class="btn btn-link text-white" style="margin-right: 20px;" onclick="window.location.href='/change_password'">
                        <i class="fas fa-lock" style="color: #FFD700;"></i> Change Password
                    </button>
                </li>
<!-- <li class="nav-item" -->
<!-- <button class="btn btn-link text-white" onclick="window.location.href='#'"> -->
<!-- <i class="fas fa-user-circle" style="color: #FFFFFF;"></i> Profile -->
<!-- </button> -->
<!-- </li> -->
                <?php endif; ?>

                <!-- Nav Item - Change Password & Profile (For Bendahara and Kepala Sekolah) -->
                <?php if ($role == 'bendahara' || $role == 'kepala_sekolah'): ?>
                <li class="nav-item">
                    <button class="btn btn-link text-white" style="margin-right: 20px;" onclick="window.location.href='/change_password'">
                        <i class="fas fa-lock" style="color: #FFD700;"></i> Change Password
                    </button>
                </li>
  <!--              <li class="nav-item">
                    <button class="btn btn-link text-white" onclick="window.location.href='#'">
                        <i class="fas fa-user-circle" style="color: #FFFFFF;"></i> Profile
                    </button>
                </li>
                <?php endif; ?>

                <div class="topbar-divider d-none d-sm-block"></div>

                <!-- Nav Item - User Information -->
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown">
                        <span class="mr-2 d-none d-lg-inline text-white small">
                            <?= session()->get('role') ?? 'User' ?> <!-- Menampilkan peran atau default 'User' jika sesi tidak ada -->
                        </span>
                        <img class="img-profile rounded-circle" src="assets/img/profile/gambar.png" style="width: 30px; height: 30px;">
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Logout
                        </a>
                    </div>
                </li>

            </ul>

        </nav>
        <!-- End of Topbar -->
