<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Pembiayaan Proyek</h2>
    <form action="/pembiayaan_proyek/update/<?= $pembiayaan_proyek['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $pembiayaan_proyek['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $pembiayaan_proyek['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama_proyek">Nama Proyek</label>
            <input type="text" class="form-control" id="nama_proyek" name="nama_proyek" value="<?= $pembiayaan_proyek['nama_proyek'] ?>" required>
        </div>
        <div class="form-group">
            <label for="anggaran_total">Anggaran Total</label>
            <input type="number" step="0.01" class="form-control" id="anggaran_total" name="anggaran_total" value="<?= $pembiayaan_proyek['anggaran_total'] ?>" required>
        </div>
        <div class="form-group">
            <label for="anggaran_terpakai">Anggaran Terpakai</label>
            <input type="number" step="0.01" class="form-control" id="anggaran_terpakai" name="anggaran_terpakai" value="<?= $pembiayaan_proyek['anggaran_terpakai'] ?>" required>
        </div>
        <button type="submit" class="btn btn-warning mt-3">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
