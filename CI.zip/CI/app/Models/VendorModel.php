<?php

namespace App\Models;

use CodeIgniter\Model;

class VendorModel extends Model
{
    protected $table = 'vendor'; // Ganti dengan nama tabel yang sesuai
    protected $primaryKey = 'id';
    protected $allowedFields = ['nama_vendor', 'kontak_vendor', 'alamat', 'keterangan'];
}
