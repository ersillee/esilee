<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Penjualan Perlengkapan Sekolah</h2>
    <form action="/penjualan_perlengkapan/update/<?= $penjualan['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $penjualan['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $penjualan['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jenis_perlengkapan">Jenis Perlengkapan</label>
            <input type="text" class="form-control" id="jenis_perlengkapan" name="jenis_perlengkapan" value="<?= $penjualan['jenis_perlengkapan'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah">Jumlah</label>
            <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?= $penjualan['jumlah'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
