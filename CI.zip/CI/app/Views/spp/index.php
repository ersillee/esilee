<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Daftar SPP</h2>
    
    <div class="mb-3">
        <a href="/pengaturan-spp" class="btn btn-secondary">Pengaturan SPP</a>
    </div>
    <div class="alert alert-info">
        Total Pemasukan Bulan Ini: <?= number_format($total_pemasukan, 2, ',', '.') ?> 
    </div>
    <a href="/spp/create" class="btn btn-primary mb-3">Tambah SPP</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Nama Siswa</th>
                <th>Jumlah yang Harus Dibayar</th>
                <th>Jumlah Dibayar</th>
                <th>Balance</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($spps as $spp): ?>
                <tr>
                    <td><?= $spp['tanggal'] ?></td>
                    <td><?= $spp['nama'] ?></td>
                    <td><?= $spp['nama_siswa'] ?></td>
                    <td><?= $spp['jumlah_yang_harus_dibayar'] ?></td>
                    <td><?= $spp['jumlah_dibayar'] ?></td>
                    <td>
                        <?php 
                            $balance = $spp['jumlah_dibayar'] - $spp['jumlah_yang_harus_dibayar'];
                            echo $balance;
                        ?>
                    </td>
                  
                    <td>
                        <a href="/spp/edit/<?= $spp['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="/spp/delete/<?= $spp['id'] ?>" method="post" style="display:inline;">
                            <input type="hidden" name="_method" value="DELETE">
                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
