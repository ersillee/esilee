(function($) {
  "use strict"; // Start of use strict

  // Toggle the side navigation
  $("#sidebarToggle, #sidebarToggleTop").on('click', function(e) {
    if ($(".sidebar").hasClass("toggled")) {
      $('.sidebar .collapse').collapse('hide');
    }
  });

  // Close any open menu accordions when window is resized below 768px
  $(window).resize(function() {
    if ($(window).width() < 768) {
      $('.sidebar .collapse').collapse('hide');
    }

    // Toggle the side navigation when window is resized below 480px
    if ($(window).width() < 480 && !$(".sidebar").hasClass("toggled")) {
      $("body").addClass("sidebar-toggled");
      $('.sidebar .collapse').collapse('hide');
    }
  });

  // Prevent the content wrapper from scrolling when the fixed side navigation hovered over
  $('body.fixed-nav .sidebar').on('mousewheel DOMMouseScroll wheel', function(e) {
    if ($(window).width() > 768) {
      var e0 = e.originalEvent,
        delta = e0.wheelDelta || -e0.detail;
      this.scrollTop += (delta < 0 ? 1 : -1) * 30;
      e.preventDefault();
    }
  });

  // Scroll to top button appear
  $(document).on('scroll', function() {
    var scrollDistance = $(this).scrollTop();
    if (scrollDistance > 100) {
      $('.scroll-to-top').fadeIn();
    } else {
      $('.scroll-to-top').fadeOut();
    }
  });

  // Smooth scrolling using jQuery easing
  $(document).on('click', 'a.scroll-to-top', function(e) {
    var $anchor = $(this);
    $('html, body').stop().animate({
      scrollTop: ($($anchor.attr('href')).offset().top)
    }, 1000, 'easeInOutExpo');
    e.preventDefault();
  });

  // Handle click on sidebar links with AJAX
  $(document).on('click', '.ajax-link', function(e) {
    e.preventDefault(); // Prevent the default behavior of the link

    var page = $(this).attr('href'); // Get the URL of the page to load

    // Load the content of the page using AJAX
    $('#content').load(page + ' #content > *', function(response, status, xhr) {
      if (status == "error") {
        var msg = "Maaf, terjadi kesalahan: ";
        $("#content").html(msg + xhr.status + " " + xhr.statusText);
      } else {
        // Optional: Update the page title or do other actions after loading new content
        var newTitle = $(response).filter('title').text(); // Get the new title from the loaded page
        document.title = newTitle; // Set the new title
      }
    });

    // Optional: Add active class to the clicked link
    $('.ajax-link').removeClass('active'); // Remove active class from all links
    $(this).addClass('active'); // Add active class to the clicked link
  });

})(jQuery); // End of use strict
