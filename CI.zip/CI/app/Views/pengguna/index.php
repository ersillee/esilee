<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $judul; ?></title>
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>

    <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>
        <a class="btn btn-primary mb-3" href="/laporan_keuangan/tambah">Tambah Laporan Keuangan</a>
        
        <div class="table-responsive">
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>ID Pengguna</th>
                        <th>Bulan Laporan</th>
                        <th>Total Pemasukan</th>
                        <th>Total Pengeluaran</th>
                        <th>Saldo</th>
                        <th>Laporan Dibuat Pada</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($laporan_keuangan)) : ?>
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada data laporan keuangan.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($laporan_keuangan as $laporan) : ?>
                        <tr>
                            <td><?= htmlspecialchars($laporan['id']); ?></td>
                            <td><?= htmlspecialchars($laporan['id_pengguna']); ?></td>
                            <td><?= htmlspecialchars($laporan['bulan_laporan']); ?></td>
                            <td><?= htmlspecialchars($laporan['total_pemasukan']); ?></td>
                            <td><?= htmlspecialchars($laporan['total_pengeluaran']); ?></td>
                            <td><?= htmlspecialchars($this->calculateBalance($laporan['total_pemasukan'], $laporan['total_pengeluaran'])); ?></td>
                            <td><?= date('d-m-Y H:i:s', strtotime($laporan['laporan_dibuat_pada'])); ?></td>
                            <td>
                                <a href="/laporan_keuangan/edit/<?= $laporan['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="/laporan_keuangan/delete/<?= $laporan['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus laporan ini?');">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/sb-admin-2.min.js"></script>
</body>

</html>
