<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Budget</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; }
        form { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; }
        input { margin-bottom: 15px; width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; }
        .btn { padding: 10px 15px; color: #fff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; cursor: pointer; }
        .btn:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <h1>Edit Budget</h1>
    <form action="<?= site_url('budget/update/' . $budget['budget_id']) ?>" method="POST">
        <label for="budget_name">Nama Budget:</label>
        <input type="text" name="budget_name" id="budget_name" value="<?= $budget['budget_name'] ?>" required>
        
        <label for="planned_amount">Jumlah Rencana:</label>
        <input type="number" name="planned_amount" id="planned_amount" step="0.01" value="<?= $budget['planned_amount'] ?>" required>
        
        <label for="actual_amount">Jumlah Aktual:</label>
        <input type="number" name="actual_amount" id="actual_amount" step="0.01" value="<?= $budget['actual_amount'] ?>">

        <label for="budget_year">Tahun Budget:</label>
        <input type="number" name="budget_year" id="budget_year" value="<?= $budget['budget_year'] ?>" required>

        <button type="submit" class="btn">Perbarui</button>
        <a href="<?= site_url('budget') ?>" class="btn">Kembali</a>
    </form>
</body>
</html>
