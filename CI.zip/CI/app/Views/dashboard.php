<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <h1>Selamat datang di Dashboard</h1>
    <p>Anda login sebagai <?= session()->get('role') ?></p>

    <?php if (session()->get('role') == 'admin' || session()->get('role') == 'bendahara'): ?>
        <a href="/financial_report">Lihat Laporan Keuangan</a>
    <?php endif; ?>

    <?php if (session()->get('role') == 'bendahara'): ?>
        <a href="/financial_report/create">Tambah Laporan Keuangan</a>
    <?php endif; ?>

    <a href="/logout">Logout</a>
</body>
</html>
