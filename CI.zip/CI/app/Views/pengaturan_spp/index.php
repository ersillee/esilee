<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Pengaturan SPP</h2>
    <a href="/pengaturan-spp/create" class="btn btn-primary mb-3">Tambah Pengaturan SPP</a>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Jumlah SPP</th>
                <th>Berlaku Mulai</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pengaturan_spp as $pengaturan): ?>
                <tr>
                    <td><?= number_format($pengaturan['jumlah_spp'], 2, ',', '.') ?></td>
                    <td><?= $pengaturan['berlaku_mulai'] ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
