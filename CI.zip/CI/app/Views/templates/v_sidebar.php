<!-- Sidebar -->
<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar" style="background-color: #e3f2fd;">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url(); ?>">
        <div class="sidebar-brand-icon">
            <i class="fas fa-school" style="color: #0d47a1;"></i>
        </div>
        <div class="sidebar-brand-text mx-3" style="color: #0d47a1;">SMK Advent Tongute Goin</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('home'); ?>" style="color: #1e2a3d;">
            <i class="fas fa-fw fa-tachometer-alt" style="color: #0d47a1;"></i>
            <span>Beranda</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Member Section -->
    <div class="sidebar-heading" style="color: #0d47a1;">
        Member
    </div>

    <?php if ($role == 'admin'): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('laporan_keuangan'); ?>" style="color: #1e2a3d;">
                <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
                <span>Laporan Keuangan</span>
            </a>
        </li>
    <?php elseif ($role == 'bendahara'): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?= base_url('laporan_keuangan'); ?>" style="color: #1e2a3d;">
                <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
                <span>Laporan Keuangan</span>
            </a>
        </li>

    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pemasukan/create'); ?>" style="color: #1e2a3d;">
            <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
            <span>Create Pemasukan</span>
        </a>
    </li>

    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pengeluaran/create'); ?>" style="color: #1e2a3d;">
            <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
            <span>Create Pengeluaran</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pengeluaran_sekolah'); ?>" style="color: #1e2a3d;">
            <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
            <span>Lihat Detail Pengeluaran</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pemasukan_sekolah'); ?>" style="color: #1e2a3d;">
            <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
            <span>Lihat Detail Pemasukan</span>
        </a>
    </li>
    <?php elseif ($role == 'kepala_sekolah'): ?>
        <li class="nav-item">
        <a class="nav-link" href="<?= base_url('laporan_keuangan'); ?>" style="color: #1e2a3d;">
            <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
            <span>Laporan Keuangan</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pengeluaran_sekolah'); ?>" style="color: #1e2a3d;">
            <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
            <span>Lihat Detail Pengeluaran</span>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link" href="<?= base_url('pemasukan_sekolah'); ?>" style="color: #1e2a3d;">
            <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
            <span>Lihat Detail Pemasukan</span>
        </a>
    </li>

    <?php endif; ?>

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

</ul>
<!-- End of Sidebar -->
