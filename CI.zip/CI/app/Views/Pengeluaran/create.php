<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Tambah Pengeluaran</h2>
    <form action="/pengeluaran/store" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
        </div>
        <div class="form-group">
            <label for="jenis_pengeluaran">Jenis Pengeluaran</label>
            <select class="form-control" id="jenis_pengeluaran" name="jenis_pengeluaran" required onchange="redirectToForm(this.value)">
                <option value="">Pilih Jenis Pengeluaran</option>
                <option value="Penggajian">Penggajian</option>
                <option value="Pembelian_Barang">Pembelian Barang</option>
                <option value="Pemeliharaan_Perawatan">Pemeliharaan Perawatan</option>
                <option value="Tagihan">Tagihan</option>
                <option value="Acara_Sekolah">Acara Sekolah</option>
                <option value="Pelatihan_Guru">Pelatihan Guru</option>
                <option value="Transportasi">Transportasi</option>
                <option value="Hutang_Sekolah">Hutang Sekolah</option>
                <option value="Pembiayaan_Proyek">Pembiayaan Proyek</option>
                <option value="beasiswa">Beasiswa</option>
                <option value="Lain-lain">Lain-lain</option>
            </select>
        </div>
    </form>
    <button type="submit" class="btn btn-primary mt-3">Simpan</button> <!-- Tambahkan tombol submit -->

</div>

<script>
function redirectToForm(jenis) {
    if (jenis) {
        // Redirect to the specific form based on selected jenis_pengeluaran
        window.location.href = '/' + jenis.replace(/\s+/g, '-').toLowerCase(); // Contoh: Penggajian menjadi /penggajian
    }
}
</script>
<?= $this->endSection() ?>
