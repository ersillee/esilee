<?php

namespace App\Controllers;

use App\Models\PemeliharaanPerawatanModel;
use App\Models\PengeluaranModel;

class PemeliharaanPerawatanController extends BaseController
{
    public function index()
    {
        $model = new PemeliharaanPerawatanModel();
        $data['pemeliharaan_perawatan'] = $model->findAll();
        
        // Mendapatkan total pengeluaran bulan ini
        $totalBulanIni = $model->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni ? $totalBulanIni['jumlah'] : 0;

        // Mendapatkan total pengeluaran seluruhnya
        $totalSeluruhnya = $model->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya ? $totalSeluruhnya['jumlah'] : 0;

        return view('pemeliharaan_perawatan/index', $data);
    }

    public function create()
    {
        return view('pemeliharaan_perawatan/create');
    }

    public function store()
    {
        $pemeliharaanModel = new PemeliharaanPerawatanModel();
        $pengeluaranModel = new \App\Models\PengeluaranModel();
    
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pemeliharaan' => $this->request->getPost('jenis_pemeliharaan'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];
    
        // Simpan ke tabel pemeliharaan_perawatan
        $pemeliharaanModel->save($data);
    
        // Simpan ke tabel pengeluaran_sekolah
        $pengeluaranData = [
            'tanggal' => $data['tanggal'],
            'nama' => $data['nama'],
            'jenis_pengeluaran' => $data['jenis_pemeliharaan'], // Sesuaikan field
            'jumlah_pengeluaran' => $data['jumlah'], // Sesuaikan field
        ];
        $pengeluaranModel->save($pengeluaranData);
    
        return redirect()->to('/pemeliharaan_perawatan');
    }
    

    public function edit($id)
    {
        $model = new PemeliharaanPerawatanModel();
        $data['pemeliharaan_perawatan'] = $model->find($id);
        return view('pemeliharaan_perawatan/edit', $data);
    }

    public function update($id)
    {
        $pemeliharaanModel = new PemeliharaanPerawatanModel();
        $pengeluaranModel = new \App\Models\PengeluaranModel();
    
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pemeliharaan' => $this->request->getPost('jenis_pemeliharaan'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];
    
        // Update tabel pemeliharaan_perawatan
        $pemeliharaanModel->update($id, $data);
    
        // Update tabel pengeluaran_sekolah (Anda mungkin perlu logika tambahan untuk mencocokkan data)
        $pengeluaranData = [
            'tanggal' => $data['tanggal'],
            'nama' => $data['nama'],
            'jenis_pengeluaran' => $data['jenis_pemeliharaan'], // Sesuaikan field
            'jumlah_pengeluaran' => $data['jumlah'], // Sesuaikan field
        ];
        $pengeluaranModel->save($pengeluaranData);
    
        return redirect()->to('/pemeliharaan_perawatan');
    }
    

    public function delete($id)
    {
        $model = new PemeliharaanPerawatanModel();
        $model->delete($id);
        return redirect()->to('/pemeliharaan_perawatan');
    }
}
