<?php

namespace App\Controllers;

use App\Models\DanaYayasanModel;
use App\Models\PemasukanModel; 
use CodeIgniter\Controller;

class DanaYayasanController extends Controller
{
    public function index()
    {
        $model = new DanaYayasanModel();
        $data['dana'] = $model->findAll();
        $total = $model->getTotalPemasukanBulanIni();
        $data['total_pemasukan'] = $total ? $total['jumlah'] : 0;
        return view('dana_yayasan/index', $data);
    }

    public function create()
    {
        return view('dana_yayasan/create');
    }

    public function store()
    {
        // Mendapatkan data dari form
        $tanggal = $this->request->getPost('tanggal');
        $nama = $this->request->getPost('nama');
        $jumlah = $this->request->getPost('jumlah');
        
        // Menyimpan data ke tabel dana_yayasan
        $danaModel = new DanaYayasanModel();
        $danaData = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jumlah' => $jumlah,
        ];
        $danaModel->insert($danaData);  // Menyimpan data ke tabel dana_yayasan

        // Menyimpan data ke tabel pemasukan_sekolah
        $pemasukanModel = new PemasukanModel();  // Pastikan model ini sudah ada
        $pemasukanData = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jenis_pemasukan' => 'Dana Yayasan',  // Menyimpan jenis pemasukan sebagai "Dana Yayasan"
            'jumlah_pemasukan' => $jumlah,
        ];
        $pemasukanModel->save($pemasukanData);  // Menyimpan data ke tabel pemasukan_sekolah

        return redirect()->to('/dana_yayasan');
    }

    public function edit($id)
    {
        $model = new DanaYayasanModel();
        $data['dana'] = $model->find($id);
        return view('dana_yayasan/edit', $data);
    }

    public function update($id)
    {
        $model = new DanaYayasanModel();
        $jumlah = $this->request->getPost('jumlah');

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jumlah' => $jumlah,
        ];

        $model->update($id, $data);
        return redirect()->to('/dana_yayasan');
    }

    public function delete($id)
    {
        $model = new DanaYayasanModel();
        $model->delete($id);
        return redirect()->to('/dana_yayasan');
    }
}
