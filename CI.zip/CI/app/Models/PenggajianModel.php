<?php
namespace App\Models;

use CodeIgniter\Model;

class PenggajianModel extends Model
{
    protected $table = 'penggajian'; // Pastikan ini sesuai dengan nama tabel Anda
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'nama_penerima','jabatan', 'jumlah_gaji'];

    public function getTotalPengeluaranBulanIni()
    {
        return $this->selectSum('jumlah_gaji') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }

    public function getTotalPengeluaranSeluruhnya()
    {
        return $this->selectSum('jumlah_gaji') // Menggunakan selectSum untuk menghitung total seluruh pengeluaran
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
