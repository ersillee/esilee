<!-- app/Views/pemasukan/edit.php -->
<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Pemasukan</h2>
    <form action="/pemasukan/update/<?= $pemasukan['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $pemasukan['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jenis_pemasukan">Jenis Pemasukan</label>
            <select class="form-control" id="jenis_pemasukan" name="jenis_pemasukan" required>
                <option value="SPP" <?= $pemasukan['jenis_pemasukan'] == 'SPP' ? 'selected' : '' ?>>SPP</option>
                <option value="Pendaftaran" <?= $pemasukan['jenis_pemasukan'] == 'Pendaftaran' ? 'selected' : '' ?>>Pendaftaran</option>
                <option value="Subsidi" <?= $pemasukan['jenis_pemasukan'] == 'Subsidi' ? 'selected' : '' ?>>Subsidi</option>
                <option value="Donasi" <?= $pemasukan['jenis_pemasukan'] == 'Donasi' ? 'selected' : '' ?>>Donasi</option>
                <option value="Penyewaan" <?= $pemasukan['jenis_pemasukan'] == 'Penyewaan' ? 'selected' : '' ?>>Penyewaan</option>
                <option value="Penjualan" <?= $pemasukan['jenis_pemasukan'] == 'Penjualan' ? 'selected' : '' ?>>Penjualan</option>
                <option value="Dana Yayasan" <?= $pemasukan['jenis_pemasukan'] == 'Dana Yayasan' ? 'selected' : '' ?>>Dana Yayasan</option>
            </select>
        </div>
        <div class="form-group">
            <label for="jumlah_pemasukan">Jumlah Pemasukan</label>
            <input type="number" class="form-control" id="jumlah_pemasukan" name="jumlah_pemasukan" value="<?= $pemasukan['jumlah_pemasukan'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
