<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Data Hutang Sekolah</h2>
    <div class="alert alert-info">
        Total Pengeluaran Bulan Ini: <?= number_format($total_pengeluaran_bulan_ini, 2, ',', '.') ?> 
    </div>
    <div class="alert alert-info">
        Total Pengeluaran: <?= number_format($total_pengeluaran_seluruhnya, 2, ',', '.') ?>
    </div>
    <a href="/hutang_sekolah/create" class="btn btn-primary mb-3">Tambah Hutang Sekolah</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Pemberi Hutang</th>
                <th>Jumlah Hutang</th>
                <th>Dibayar</th>
                <th>Tanggal Jatuh Tempo</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($hutang_sekolah as $item): ?>
                <tr>
                    <td><?= $item['id'] ?></td>
                    <td><?= $item['tanggal'] ?></td>
                    <td><?= $item['nama'] ?></td>
                    <td><?= $item['pemberi_hutang'] ?></td>
                    <td><?= $item['jumlah_hutang'] ?></td>
                    <td><?= number_format($item['dibayar'], 2, ',', '.') ?></td>
                    <td><?= $item['tanggal_jatuh_tempo'] ?></td>
                    <td>
                        <a href="/hutang_sekolah/edit/<?= $item['id'] ?>" class="btn btn-warning">Edit</a>
                        <form action="/hutang_sekolah/delete/<?= $item['id'] ?>" method="post" style="display:inline;">
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
