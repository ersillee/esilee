<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Tambah Hutang Sekolah</h2>
    <form action="/hutang_sekolah/store" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" required>
        </div>
        <div class="form-group">
            <label for="pemberi_hutang">Pemberi Hutang</label>
            <input type="text" class="form-control" id="pemberi_hutang" name="pemberi_hutang" required>
        </div>
        <div class="form-group">
            <label for="jumlah_hutang">Jumlah Hutang</label>
            <input type="number" class="form-control" id="jumlah_hutang" name="jumlah_hutang" required>
        </div>
        <div class="form-group">
            <label for="jumlah_hutang">Dibayar</label>
            <input type="number" class="form-control" id="dibayar" name="dibayar" required>
        </div>
        <div class="form-group">
            <label for="tanggal_jatuh_tempo">Tanggal Jatuh Tempo</label>
            <input type="date" class="form-control" id="tanggal_jatuh_tempo" name="tanggal_jatuh_tempo" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Simpan</button>
    </form>
</div>
<?= $this->endSection() ?>
