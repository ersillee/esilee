<!-- edit_account.php -->
<h2>Edit Account</h2>

<form action="<?= base_url('admin/updateAccount/' . $user['id']) ?>" method="post">
    <label>Username:</label>
    <input type="text" name="username" value="<?= esc($user['username']) ?>" required><br>

    <label>Password:</label>
    <input type="password" name="password" value="<?= esc($user['password']) ?>" required><br>

    <label>Role:</label>
    <select name="role">
        <option value="admin" <?= $user['role'] === 'admin' ? 'selected' : '' ?>>Admin</option>
        <option value="bendahara" <?= $user['role'] === 'bendahara' ? 'selected' : '' ?>>Bendahara</option>
        <option value="kepala sekolah" <?= $user['role'] === 'kepala sekolah' ? 'selected' : '' ?>>Kepala Sekolah</option>
    </select><br>

    <button type="submit">Save Changes</button>
</form>
