<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Pengeluaran Transportasi</h2>
    <form action="/transportasi/update/<?= $transportasi['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $transportasi['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $transportasi['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jenis_kegiatan">Jenis Kegiatan</label>
            <input type="text" class="form-control" id="jenis_kegiatan" name="jenis_kegiatan" value="<?= $transportasi['jenis_kegiatan'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah">Jumlah</label>
            <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?= $transportasi['jumlah'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
