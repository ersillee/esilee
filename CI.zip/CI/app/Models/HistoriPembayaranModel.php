<?php

namespace App\Models;

use CodeIgniter\Model;

class HistoriPembayaranModel extends Model
{
    protected $table = 'histori_pembayaran'; // Nama tabel di database
    protected $primaryKey = 'id'; // Primary key tabel

    protected $allowedFields = [
        'id_siswa',
        'jumlah_pembayaran',
        'metode_pembayaran',
        'tanggal_pembayaran',
        'created',
        'updated'
    ];

    protected $useTimestamps = true; // Menggunakan timestamps

    // Mengambil semua data dari tabel
    public function getAllData()
    {
        return $this->findAll();
    }

    // Menambahkan data baru ke tabel
    public function tambah($data)
    {
        return $this->insert($data);
    }

    // Mengambil data berdasarkan ID
    public function getDataById($id)
    {
        return $this->find($id);
    }

    // Memperbarui data berdasarkan ID
    public function edit($data, $id)
    {
        return $this->update($id, $data);
    }

    // Menghapus data berdasarkan ID
    public function hapus($id)
    {
        return $this->delete($id);
    }
}
