<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Daftar Pengeluaran Beasiswa</h2>
    <div class="alert alert-info">
        Total Pengeluaran Bulan Ini: <?= number_format($total_pemasukan, 2, ',', '.') ?> 
    </div>
    <a href="/beasiswa/create" class="btn btn-primary mb-3">Tambah Pengeluaran Beasiswa</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Nama Siswa</th>
                <th>Jenis Beasiswa</th>
                <th>Jumlah Beasiswa</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($beasiswa as $b): ?>
                <tr>
                    <td><?= $b['tanggal'] ?></td>
                    <td><?= $b['nama'] ?></td>
                    <td><?= $b['nama_siswa'] ?></td>
                    <td><?= $b['jenis_beasiswa'] ?></td>
                    <td><?= $b['jumlah_beasiswa'] ?></td>
                
                    <td>
                        <a href="/beasiswa/edit/<?= $b['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="/beasiswa/delete/<?= $b['id'] ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
