<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Tambah Pembiayaan Proyek</h2>
    <form action="/pembiayaan_proyek/store" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" required>
        </div>
        <div class="form-group">
            <label for="nama_proyek">Nama Proyek</label>
            <input type="text" class="form-control" id="nama_proyek" name="nama_proyek" required>
        </div>
        <div class="form-group">
            <label for="anggaran_total">Anggaran Total</label>
            <input type="number" step="0.01" class="form-control" id="anggaran_total" name="anggaran_total" required>
        </div>
        <div class="form-group">
            <label for="anggaran_terpakai">Anggaran Terpakai</label>
            <input type="number" step="0.01" class="form-control" id="anggaran_terpakai" name="anggaran_terpakai" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Simpan</button>
    </form>
</div>
<?= $this->endSection() ?>
