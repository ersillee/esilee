<?php

namespace App\Models;

use CodeIgniter\Model;

class ChangePasswordModel extends Model
{
    protected $table = 'change_password'; // Sesuaikan dengan nama tabel Anda
    protected $primaryKey = 'id'; // Sesuaikan dengan primary key
    protected $allowedFields = ['user_id', 'old_password', 'new_password', 'created_at']; // Sesuaikan dengan kolom di tabel

    public function getChangePasswordData()
    {
        return $this->findAll(); // Mengambil semua data dari tabel
    }
}
