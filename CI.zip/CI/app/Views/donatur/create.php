<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Donatur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin: 10px 0 5px;
        }
        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        a {
            text-decoration: none;
            color: blue;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<h1>Tambah Donatur</h1>
<form action="/donatur/store" method="post">
    <label>Nama Donatur:</label>
    <input type="text" name="nama_donatur" required>
    <label>Kontak Donatur:</label>
    <input type="text" name="kontak_donatur" required>
    <label>Jumlah Sumbangan:</label>
    <input type="number" name="jumlah_sumbangan" required>
    <label>Tanggal Sumbangan:</label>
    <input type="date" name="tanggal_sumbangan" required>
    <label>Keterangan:</label>
    <textarea name="keterangan"></textarea>
    <button type="submit">Simpan</button>
</form>

</body>
</html>
