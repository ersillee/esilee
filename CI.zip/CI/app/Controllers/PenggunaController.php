<?php

namespace App\Controllers;

use App\Models\PenggunaModel;

class PenggunaController extends BaseController
{
    public function index()
    {
        $model = new PenggunaModel();
        $data['pengguna'] = $model->findAll();
        $data['judul'] = 'Daftar Pengguna';
        return view('pengguna/index', $data);
    }

    public function create()
    {
        $data['judul'] = 'Tambah Pengguna';
        return view('pengguna/create', $data);
    }

    public function store()
    {
        $model = new PenggunaModel();

        // Validasi input
        $data = [
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'peran' => $this->request->getPost('peran'),
        ];

        $model->insert($data);
        return redirect()->to('/pengguna');
    }

    public function edit($id)
    {
        $model = new PenggunaModel();
        $data['pengguna'] = $model->find($id);
        $data['judul'] = 'Edit Pengguna';
        return view('pengguna/edit', $data);
    }

    public function update($id)
    {
        $model = new PenggunaModel();

        // Validasi input
        $data = [
            'username' => $this->request->getPost('username'),
            'peran' => $this->request->getPost('peran'),
        ];

        $password = $this->request->getPost('password');
        if ($password) {
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $model->update($id, $data);
        return redirect()->to('/pengguna');
    }

    public function delete($id)
    {
        $model = new PenggunaModel();
        $model->delete($id);
        return redirect()->to('/pengguna');
    }
}
