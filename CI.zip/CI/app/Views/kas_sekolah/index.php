<h2>Kas Sekolah</h2>
<p>Saldo Awal: Rp <?= number_format($saldo_awal, 2, ',', '.') ?></p>
<p>Saldo Akhir Bulan Ini: Rp <?= number_format($saldo_akhir, 2, ',', '.') ?></p>
