<?php

namespace App\Models;

use CodeIgniter\Model;

class DanaYayasanModel extends Model
{
    protected $table = 'dana_yayasan';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'jumlah'];

    public function getTotalPemasukanBulanIni()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
