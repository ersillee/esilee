<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Donasi</h2>
    <form action="/donasi/update/<?= $donasi['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $donasi['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $donasi['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="asal_donasi">Asal Donasi</label>
            <input type="text" class="form-control" id="asal_donasi" name="asal_donasi" value="<?= $donasi['asal_donasi'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah_donasi">Jumlah Donasi</label>
            <input type="number" class="form-control" id="jumlah_donasi" name="jumlah_donasi" value="<?= $donasi['jumlah_donasi'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
