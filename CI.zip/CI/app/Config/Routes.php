<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/login', 'AuthController::login');
$routes->get('/', 'AuthController::login');
$routes->post('/auth/authenticate', 'AuthController::authenticate');
$routes->get('/logout', 'AuthController::logout');
$routes->get('/dashboard', 'DashboardController::index', ['filter' => 'auth']);




$routes->get('/', 'Home::index');
$routes->get('home', 'Home::index');

$routes->get('/admin', 'AdminController::index');
$routes->get('/bendahara', 'BendaharaController::index');
$routes->get('/kepala_sekolah', 'KepalaSekolahController::index');

$routes->get('/admin', 'HomeController::adminOnly', ['filter' => 'role:admin']);
$routes->get('/bendahara', 'HomeController::bendaharaOnly', ['filter' => 'role:bendahara']);
$routes->get('/kepala_sekolah', 'HomeController::kepalaSekolahOnly', ['filter' => 'role:kepala_sekolah']);


$routes->group('', ['filter' => 'userRole:admin'], function($routes) {
    $routes->get('/admin', 'AdminController::index'); // Hanya untuk Admin
    $routes->get('/manage-users', 'AdminController::manageUsers'); // Untuk manajemen pengguna
    // Rute lainnya untuk Admin
});

$routes->group('', ['filter' => 'userRole:bendahara'], function($routes) {
    $routes->get('/bendahara', 'BendaharaController::index'); // Hanya untuk Bendahara
    $routes->get('/financial-reports', 'BendaharaController::financialReports'); // Untuk laporan keuangan
    // Rute lainnya untuk Bendahara
});

$routes->group('', ['filter' => 'userRole:kepala_sekolah'], function($routes) {
    $routes->get('/kepala-sekolah', 'KepalaSekolahController::index'); // Hanya untuk Kepala Sekolah
    $routes->get('/financial-reports', 'KepalaSekolahController::financialReports'); // Hanya melihat laporan keuangan
});



$routes->get('/register', 'RegisterController::register');
$routes->post('/register/submit', 'RegisterController::submit');

$routes->get('siswa', 'Siswa::index');
$routes->get('siswa/tambah', 'Siswa::tambah');
$routes->post('siswa/tambah', 'Siswa::tambah');
$routes->get('siswa/hapus/(:num)', 'Siswa::hapus/$1');
$routes->get('siswa/edit/(:num)', 'Siswa::edit/$1'); // Untuk menampilkan form edit

$routes->get('change_password', 'ChangePasswordController::index');
$routes->post('change-password/update', 'ChangePasswordController::update');


$routes->get('pembayaran', 'PembayaranController::histori');
$routes->get('pembayaran/tambah', 'PembayaranController::tambah');
$routes->post('pembayaran/simpan', 'PembayaranController::simpan');
$routes->get('pembayaran/edit/(:num)', 'PembayaranController::edit/$1');
$routes->post('pembayaran/update/(:num)', 'PembayaranController::update/$1');
$routes->get('pembayaran/hapus/(:num)', 'PembayaranController::hapus/$1');


$routes->get('/pengeluaran_sekolah', 'PengeluaranController::index');
$routes->get('pengeluaran', 'PengeluaranController::index');
$routes->get('pengeluaran/create', 'PengeluaranController::create');
$routes->post('pengeluaran', 'PengeluaranController::store');
$routes->post('pengeluaran/store', 'PengeluaranController::store');
$routes->get('pengeluaran/edit/(:num)', 'PengeluaranController::edit/$1');
$routes->post('pengeluaran/update/(:num)', 'PengeluaranController::update/$1');
$routes->get('pengeluaran/hapus/(:num)', 'PengeluaranController::hapus/$1');
$routes->post('pengeluaran/delete/(:num)', 'PengeluaranController::delete/$1');
$routes->post('/pengeluaran/storeAll', 'PengeluaranController::storeAll');
$routes->post('/pengeluaran/hapusPerBulan', 'PengeluaranController::hapusPerBulan');
$routes->get('hapus-pengeluaran/(:num)/(:num)', 'PengeluaranController::hapusData/$1/$2');
$routes->post('pengeluaran/hapusData', 'PengeluaranController::hapusData');






$routes->get('penggajian/storeToPengeluaran', 'PenggajianController::storeToPengeluaran');
$routes->get('financial/add/pengeluaran', 'FinancialController::addPengeluaran');



$routes->get('/beasiswa', 'BeasiswaController::index');
$routes->get('/beasiswa/create', 'BeasiswaController::create');
$routes->post('/beasiswa/store', 'BeasiswaController::store');
$routes->get('/beasiswa/edit/(:num)', 'BeasiswaController::edit/$1');
$routes->post('/beasiswa/update/(:num)', 'BeasiswaController::update/$1');
$routes->get('/beasiswa/delete/(:num)', 'BeasiswaController::delete/$1');

$routes->get('donatur', 'DonaturController::index');
$routes->get('donatur/create', 'DonaturController::create');
$routes->post('donatur/store', 'DonaturController::store');
$routes->get('donatur/edit/(:num)', 'DonaturController::edit/$1');
$routes->post('donatur/update/(:num)', 'DonaturController::update/$1');
$routes->get('donatur/delete/(:num)', 'DonaturController::delete/$1');

$routes->get('pengguna', 'PenggunaController::index');
$routes->get('pengguna/create', 'PenggunaController::create');
$routes->post('pengguna/store', 'PenggunaController::store');
$routes->get('pengguna/edit/(:num)', 'PenggunaController::edit/$1');
$routes->post('pengguna/update/(:num)', 'PenggunaController::update/$1');
$routes->get('pengguna/delete/(:num)', 'PenggunaController::delete/$1');

$routes->get('/kas_sekolah/create', 'KasSekolahController::create');
$routes->post('/kas_sekolah/store', 'KasSekolahController::store');
$routes->get('/kas_sekolah/edit/(:num)', 'KasSekolahController::edit/$1');
$routes->post('/kas_sekolah/update/(:num)', 'KasSekolahController::update/$1');
$routes->get('/kas_sekolah/hapus/(:num)', 'KasSekolahController::hapus/$1');
$routes->get('kas_sekolah', 'KasSekolahController::index');



$routes->get('/hutang_sekolah', 'HutangSekolahController::index');
$routes->get('/hutang_sekolah/create', 'HutangSekolahController::create');
$routes->post('/hutang_sekolah/store', 'HutangSekolahController::store');
$routes->get('/hutang_sekolah/edit/(:num)', 'HutangSekolahController::edit/$1');
$routes->post('/hutang_sekolah/update/(:num)', 'HutangSekolahController::update/$1');
$routes->post('/hutang_sekolah/delete/(:num)', 'HutangSekolahController::delete/$1');

$routes->get('invoices', 'InvoicesController::index'); // Menampilkan daftar invoice
$routes->get('invoices/tambah', 'InvoicesController::tambahPage'); // Menampilkan halaman tambah invoice
$routes->post('invoices/tambah', 'InvoicesController::tambah'); // Menyimpan invoice baru
$routes->get('invoices/edit/(:num)', 'InvoicesController::editPage/$1'); // Menampilkan halaman edit invoice
$routes->post('invoices/update/(:num)', 'InvoicesController::update/$1'); // Memperbarui invoice
$routes->get('invoices/hapus/(:num)', 'InvoicesController::hapus/$1'); // Menghapus invoice


$routes->get('/roles', 'RoleController::index');
$routes->get('/roles/create', 'RoleController::create');
$routes->post('/roles/store', 'RoleController::store');
$routes->get('/roles/edit/(:num)', 'RoleController::edit/$1');
$routes->post('/roles/update/(:num)', 'RoleController::update/$1');
$routes->get('/roles/delete/(:num)', 'RoleController::delete/$1');


$routes->get('financial-report/realtime', 'FinancialReportController::getRealTimeData');


$routes->get('/pembelian_barang', 'PembelianBarangController::index');
$routes->get('/pembelian_barang/create', 'PembelianBarangController::create');
$routes->post('/pembelian_barang/store', 'PembelianBarangController::store');
$routes->get('/pembelian_barang/edit/(:num)', 'PembelianBarangController::edit/$1');
$routes->post('/pembelian_barang/update/(:num)', 'PembelianBarangController::update/$1');
$routes->post('/pembelian_barang/delete/(:num)', 'PembelianBarangController::delete/$1');

$routes->get('/penggajian', 'PenggajianController::index');
$routes->get('/penggajian/create', 'PenggajianController::create');
$routes->post('/penggajian/store', 'PenggajianController::store');
$routes->get('/penggajian/store', 'PenggajianController::store');
$routes->get('/penggajian/edit/(:num)', 'PenggajianController::edit/$1');
$routes->post('/penggajian/update/(:num)', 'PenggajianController::update/$1');
$routes->post('/penggajian/delete/(:num)', 'PenggajianController::delete/$1');



// Rute untuk PembiayaanProyek
$routes->get('/pembiayaan_proyek', 'PembiayaanProyekController::index');
$routes->get('/pembiayaan_proyek/create', 'PembiayaanProyekController::create');
$routes->post('/pembiayaan_proyek/store', 'PembiayaanProyekController::store');
$routes->get('/pembiayaan_proyek/edit/(:num)', 'PembiayaanProyekController::edit/$1');
$routes->post('/pembiayaan_proyek/update/(:num)', 'PembiayaanProyekController::update/$1');
$routes->post('/pembiayaan_proyek/delete/(:num)', 'PembiayaanProyekController::delete/$1');


$routes->get('laporan_keuangan/tambah', 'LaporanKeuangan::tambah');
$routes->post('laporan_keuangan/store', 'LaporanKeuangan::store');
$routes->get('laporan_keuangan/edit/(:num)', 'LaporanKeuangan::edit/$1');
$routes->post('laporan_keuangan/update/(:num)', 'LaporanKeuangan::update/$1');
$routes->get('laporan_keuangan/delete/(:num)', 'LaporanKeuangan::delete/$1');

$routes->get('/laporan_keuangan', 'LaporanKeuangan::index');


$routes->get('/pemeliharaan_perawatan', 'PemeliharaanPerawatanController::index');
$routes->get('/pemeliharaan_perawatan/create', 'PemeliharaanPerawatanController::create');
$routes->post('/pemeliharaan_perawatan/store', 'PemeliharaanPerawatanController::store');
$routes->get('/pemeliharaan_perawatan/edit/(:num)', 'PemeliharaanPerawatanController::edit/$1');
$routes->post('/pemeliharaan_perawatan/update/(:num)', 'PemeliharaanPerawatanController::update/$1');
$routes->post('/pemeliharaan_perawatan/delete/(:num)', 'PemeliharaanPerawatanController::delete/$1');

$routes->get('/acara_sekolah', 'AcaraSekolahController::index');
$routes->get('/acara_sekolah/create', 'AcaraSekolahController::create');
$routes->post('/acara_sekolah/store', 'AcaraSekolahController::store');
$routes->get('/acara_sekolah/edit/(:num)', 'AcaraSekolahController::edit/$1');
$routes->post('/acara_sekolah/update/(:num)', 'AcaraSekolahController::update/$1');
$routes->post('/acara_sekolah/delete/(:num)', 'AcaraSekolahController::delete/$1');

$routes->get('/pelatihan_guru', 'PelatihanGuruController::index');
$routes->get('/pelatihan_guru/create', 'PelatihanGuruController::create');
$routes->post('/pelatihan_guru/store', 'PelatihanGuruController::store');
$routes->get('/pelatihan_guru/edit/(:num)', 'PelatihanGuruController::edit/$1');
$routes->post('/pelatihan_guru/update/(:num)', 'PelatihanGuruController::update/$1');
$routes->post('/pelatihan_guru/delete/(:num)', 'PelatihanGuruController::delete/$1');

$routes->get('tagihan', 'TagihanController::index');
$routes->get('tagihan/create', 'TagihanController::create');
$routes->post('tagihan/store', 'TagihanController::store');
$routes->get('tagihan/edit/(:num)', 'TagihanController::edit/$1');
$routes->post('tagihan/update/(:num)', 'TagihanController::update/$1');
$routes->post('tagihan/delete/(:num)', 'TagihanController::delete/$1');


$routes->get('/transportasi', 'TransportasiController::index');
$routes->get('/transportasi/create', 'TransportasiController::create');
$routes->post('/transportasi/store', 'TransportasiController::store');
$routes->get('/transportasi/edit/(:num)', 'TransportasiController::edit/$1');
$routes->post('/transportasi/update/(:num)', 'TransportasiController::update/$1');
$routes->post('/transportasi/delete/(:num)', 'TransportasiController::delete/$1');

$routes->get('/pemasukan', 'PemasukanController::index');
$routes->get('/pemasukan_sekolah', 'PemasukanController::index');
$routes->get('/pemasukan/create', 'PemasukanController::create');
$routes->post('/pemasukan/store', 'PemasukanController::store');
$routes->get('/pemasukan/edit/(:num)', 'PemasukanController::edit/$1');
$routes->post('/pemasukan/update/(:num)', 'PemasukanController::update/$1');
$routes->get('/pemasukan/delete/(:num)', 'PemasukanController::delete/$1');
$routes->post('pemasukan/storeAll', 'PemasukanController::storeAll');


$routes->get('/pendaftaran', 'PendaftaranController::index');           // Menampilkan semua data pendaftaran
$routes->get('/pendaftaran/create', 'PendaftaranController::create');    // Menampilkan form tambah data
$routes->post('/pendaftaran/store', 'PendaftaranController::store');     // Menyimpan data baru
$routes->get('/pendaftaran/edit/(:num)', 'PendaftaranController::edit/$1'); // Menampilkan form edit data berdasarkan ID
$routes->post('/pendaftaran/update/(:num)', 'PendaftaranController::update/$1'); // Mengupdate data yang sudah ada
$routes->get('/pendaftaran/delete/(:num)', 'PendaftaranController::delete/$1');  // Menghapus data berdasarkan ID


$routes->get('/donasi', 'DonasiController::index');
$routes->get('/donasi/create', 'DonasiController::create');
$routes->post('/donasi/store', 'DonasiController::store');
$routes->get('/donasi/edit/(:num)', 'DonasiController::edit/$1');
$routes->post('/donasi/update/(:num)', 'DonasiController::update/$1');
$routes->get('/donasi/delete/(:num)', 'DonasiController::delete/$1');

$routes->get('/penyewaan_fasilitas', 'PenyewaanFasilitasController::index');
$routes->get('/penyewaan_fasilitas/create', 'PenyewaanFasilitasController::create');
$routes->post('/penyewaan_fasilitas/store', 'PenyewaanFasilitasController::store');
$routes->get('/penyewaan_fasilitas/edit/(:num)', 'PenyewaanFasilitasController::edit/$1');
$routes->post('/penyewaan_fasilitas/update/(:num)', 'PenyewaanFasilitasController::update/$1');
$routes->get('/penyewaan_fasilitas/delete/(:num)', 'PenyewaanFasilitasController::delete/$1');

$routes->get('/penjualan_perlengkapan', 'PenjualanPerlengkapanController::index');
$routes->get('/penjualan_perlengkapan/create', 'PenjualanPerlengkapanController::create');
$routes->post('/penjualan_perlengkapan/store', 'PenjualanPerlengkapanController::store');
$routes->get('/penjualan_perlengkapan/edit/(:num)', 'PenjualanPerlengkapanController::edit/$1');
$routes->post('/penjualan_perlengkapan/update/(:num)', 'PenjualanPerlengkapanController::update/$1');
$routes->get('/penjualan_perlengkapan/delete/(:num)', 'PenjualanPerlengkapanController::delete/$1');

$routes->get('/dana_yayasan', 'DanaYayasanController::index');
$routes->get('/dana_yayasan/create', 'DanaYayasanController::create');
$routes->post('/dana_yayasan/store', 'DanaYayasanController::store');
$routes->get('/dana_yayasan/edit/(:num)', 'DanaYayasanController::edit/$1');
$routes->post('/dana_yayasan/update/(:num)', 'DanaYayasanController::update/$1');
$routes->get('/dana_yayasan/delete/(:num)', 'DanaYayasanController::delete/$1');

$routes->get('/spp', 'SPPController::index');
$routes->get('/spp/spp', 'SPPController::spp');
$routes->get('/spp', 'SPPController::index');
$routes->get('/spp/create', 'SPPController::create'); // Rute untuk halaman create
$routes->post('/spp/store', 'SPPController::store');  // Rute untuk menyimpan data
$routes->get('/spp/edit/(:num)', 'SPPController::edit/$1'); // Rute untuk mengedit data dengan ID
$routes->post('/spp/update/(:num)', 'SPPController::update/$1'); // Rute untuk memperbarui data
$routes->get('/spp/delete/(:num)', 'SPPController::delete/$1'); // Rute untuk menghapus data


$routes->get('/register', 'RegisterController::index');
$routes->post('/register', 'RegisterController::register');

$routes->get('lain-lain', 'PengeluaranController::index');

$routes->get('admin/add-account', 'AdminController::addAccountForm');
$routes->post('admin/add-account', 'AdminController::addAccount');
//$routes->post('admin/create-account', 'AdminController::addAccount');
$routes->get('admin/deleteAccount/(:num)', 'AdminController::deleteAccount/$1');
$routes->post('admin/deleteAccount/(:num)', 'AdminController::deleteAccount/$1');
$routes->post('admin/updateAccount/(:num)', 'AdminController::updateAccount/$1');
$routes->get('admin/editAccount/(:num)', 'RegisterController::edit/$1');
$routes->post('admin/editAccount/(:num)', 'RegisterController::edit/$1'); // Untuk menyimpan perubahan setelah form disubmit
$routes->get('register/deleteAccount/(:num)', 'RegisterController::delete/$1');
$routes->post('register/deleteAccount/(:num)', 'RegisterController::delete/$1'); // Untuk menghapus akun

$routes->get('/admin/list_account', 'AdminController::listAccount');

$routes->get('subsidi', 'SubsidiController::index'); // Untuk halaman index subsidi
$routes->get('subsidi/create', 'SubsidiController::create'); // Untuk halaman form create subsidi
$routes->get('subsidi/edit/(:num)', 'SubsidiController::edit/$1'); // Untuk halaman edit subsidi
$routes->post('subsidi/update/(:num)', 'SubsidiController::update/$1'); // Untuk update subsidi
$routes->post('subsidi/store', 'SubsidiController::store');
$routes->get('subsidi/delete/(:num)', 'SubsidiController::delete/$1');




$routes->get('pengaturan-spp', 'PengaturanSPPController::index');
$routes->get('pengaturan-spp/create', 'PengaturanSPPController::create');
$routes->post('pengaturan-spp/store', 'PengaturanSPPController::store');
