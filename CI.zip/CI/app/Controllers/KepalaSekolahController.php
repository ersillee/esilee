<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class KepalaSekolahController extends Controller
{
    public function __construct()
    {
        // Memeriksa apakah pengguna adalah kepala sekolah
        if (session()->get('role') !== 'kepala_sekolah') {
            return redirect()->to('/home'); // Arahkan ke home jika bukan kepala sekolah
        }
    }

    public function index()
    {
        return view('kepala_sekolah/index');
    }

    // Tambahkan metode lainnya di sini
}
