<?php

namespace App\Controllers;
use App\Models\DonasiModel;
use App\Models\PemasukanModel;
use CodeIgniter\Controller;

class DonasiController extends Controller
{
    public function index()
    {
        $model = new DonasiModel();
        $data['donasi'] = $model->findAll();
        $total = $model->getTotalPemasukanBulanIni();
        $data['total_pemasukan'] = $total ? $total['jumlah_donasi'] : 0;
        return view('donasi/index', $data);
    }

    public function create()
    {
        return view('donasi/create');
    }

    public function store()
    {
        $donasiModel = new DonasiModel();
        $pemasukanModel = new PemasukanModel();
    
        // Mendapatkan data dari form
        $jumlahDonasi = $this->request->getPost('jumlah_donasi');
        $nama = $this->request->getPost('nama');
        $tanggal = $this->request->getPost('tanggal');
        $asalDonasi = $this->request->getPost('asal_donasi');
    
        // Data yang akan disimpan ke tabel donasi
        $dataDonasi = [
            'tanggal' => $tanggal,
            'tanggal' => $nama,
            'asal_donasi' => $asalDonasi,
            'jumlah_donasi' => $jumlahDonasi,
        ];
    
        // Menyimpan data donasi ke tabel donasi
        $donasiModel->insert($dataDonasi);
    
        // Data yang akan disimpan ke tabel pemasukan_sekolah
        $dataPemasukan = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jenis_pemasukan' => 'Donasi',  // Menyimpan jenis pemasukan sebagai 'Donasi'
            'jumlah_pemasukan' => $jumlahDonasi,
        ];
    
        // Menyimpan data ke tabel pemasukan_sekolah
        $pemasukanModel->save($dataPemasukan);
    
        // Redirect setelah berhasil menyimpan
        return redirect()->to('/donasi')->with('message', 'Data donasi berhasil disimpan.');
    }
    

    public function edit($id)
    {
        $model = new DonasiModel();
        $data['donasi'] = $model->find($id);
        return view('donasi/edit', $data);
    }

    public function update($id)
    {
        $model = new DonasiModel();
        $jumlahDonasi = $this->request->getPost('jumlah_donasi');

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'asal_donasi' => $this->request->getPost('asal_donasi'),
            'jumlah_donasi' => $jumlahDonasi
        ];

        $model->update($id, $data);
        return redirect()->to('/donasi');
    }

    public function delete($id)
    {
        $model = new DonasiModel();
        $model->delete($id);
        return redirect()->to('/donasi');
    }
}
