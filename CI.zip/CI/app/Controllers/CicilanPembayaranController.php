<?php

namespace App\Controllers;

use App\Models\CicilanPembayaranModel;

class CicilanPembayaranController extends BaseController
{
    protected $cicilanModel;

    public function __construct()
    {
        $this->cicilanModel = new CicilanPembayaranModel();
    }

    public function index()
    {
        $data['cicilan'] = $this->cicilanModel->findAll();
        return view('cicilan_pembayaran/index', $data);
    }

    public function create()
    {
        return view('cicilan_pembayaran/create');
    }

    public function store()
    {
        $data = [
            'id_siswa' => $this->request->getPost('id_siswa'),
            'jumlah_cicilan' => $this->request->getPost('jumlah_cicilan'),
            'tanggal_jatuh_tempo' => $this->request->getPost('tanggal_jatuh_tempo'),
            'status' => $this->request->getPost('status'),
        ];

        $this->cicilanModel->save($data);
        return redirect()->to('/cicilan_pembayaran');
    }

    public function edit($id)
    {
        $data['cicilan'] = $this->cicilanModel->find($id);
        return view('cicilan_pembayaran/edit', $data);
    }

    public function update($id)
    {
        $data = [
            'id_siswa' => $this->request->getPost('id_siswa'),
            'jumlah_cicilan' => $this->request->getPost('jumlah_cicilan'),
            'tanggal_jatuh_tempo' => $this->request->getPost('tanggal_jatuh_tempo'),
            'status' => $this->request->getPost('status'),
        ];

        $this->cicilanModel->update($id, $data);
        return redirect()->to('/cicilan_pembayaran');
    }

    public function delete($id)
    {
        $this->cicilanModel->delete($id);
        return redirect()->to('/cicilan_pembayaran');
    }
}
