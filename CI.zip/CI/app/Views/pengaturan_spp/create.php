<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Tambah Pengaturan SPP</h2>
    <form action="/pengaturan-spp/store" method="post">
        <div class="form-group">
            <label for="jumlah_spp">Jumlah SPP</label>
            <input type="number" class="form-control" id="jumlah_spp" name="jumlah_spp" required>
        </div>
        <div class="form-group">
            <label for="berlaku_mulai">Berlaku Mulai</label>
            <input type="date" class="form-control" id="berlaku_mulai" name="berlaku_mulai" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Simpan</button>
    </form>
</div>
<?= $this->endSection() ?>
