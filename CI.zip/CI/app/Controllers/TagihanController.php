<?php

namespace App\Controllers;

use App\Models\TagihanModel;
use App\Models\PengeluaranModel;

class TagihanController extends BaseController
{
    public function index()
    {
        $model = new TagihanModel();
        $data['tagihan'] = $model->findAll();

        $totalBulanIni = $model->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni ? $totalBulanIni['jumlah'] : 0;

        // Mendapatkan total pengeluaran seluruhnya
        $totalSeluruhnya = $model->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya ? $totalSeluruhnya['jumlah'] : 0;

        return view('tagihan/index', $data);
    }

    public function create()
    {
        return view('tagihan/create');
    }

    public function store()
    {
        $tagihanModel = new TagihanModel();
        $pengeluaranModel = new PengeluaranModel();

        $dataTagihan = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_tagihan' => $this->request->getPost('jenis_tagihan'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];

        // Simpan ke tabel tagihan
        $tagihanModel->save($dataTagihan);

        // Simpan ke tabel pengeluaran_sekolah
        $dataPengeluaran = [
            'tanggal' => $dataTagihan['tanggal'],
            'nama' => $dataTagihan['nama'],
            'jenis_pengeluaran' => $dataTagihan['jenis_tagihan'],
            'jumlah_pengeluaran' => $dataTagihan['jumlah'],
        ];

        $pengeluaranModel->save($dataPengeluaran);

        return redirect()->to('/tagihan');
    }

    public function edit($id)
    {
        $model = new TagihanModel();
        $data['tagihan'] = $model->find($id);
        return view('tagihan/edit', $data);
    }

    public function update($id)
    {
        $model = new TagihanModel();

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_tagihan' => $this->request->getPost('jenis_tagihan'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];

        $model->update($id, $data);
        return redirect()->to('/tagihan');
    }

    public function delete($id)
    {
        $model = new TagihanModel();
        $model->delete($id);
        return redirect()->to('/tagihan');
    }
}
