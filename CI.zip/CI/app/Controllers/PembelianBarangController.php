<?php
// app/Controllers/PembelianBarangController.php

namespace App\Controllers;

use App\Models\PembelianBarangModel;
use App\Models\PengeluaranModel;


class PembelianBarangController extends BaseController
{
    public function index()
    {
        $model = new PembelianBarangModel();
        $data['pembelian_barang'] = $model->findAll();
        
        // Mendapatkan total pengeluaran bulan ini
        $totalBulanIni = $model->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni['total_harga'] ?? 0; // Ubah 'total_harga' ke 'jumlah_harga' jika perlu

        // Mendapatkan total pengeluaran seluruhnya
        $totalSeluruhnya = $model->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya['total_harga'] ?? 0; // Ubah 'jumlah' sesuai dengan nama kolom yang ada

        return view('pembelian_barang/index', $data);
    }



    public function create()
    {
        return view('pembelian_barang/create');
    }

    public function store()
    {
        // Inisialisasi model
        $pembelianBarangModel = new PembelianBarangModel();
        $pengeluaranModel = new PengeluaranModel(); 

        // Hitung total harga
        $total_harga = $pembelianBarangModel->calculateTotalHarga(
            $this->request->getPost('jumlah_barang'), 
            $this->request->getPost('harga_satuan')
        );

        // Data untuk tabel pembelian_barang
        $pembelianData = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jumlah_barang' => $this->request->getPost('jumlah_barang'),
            'harga_satuan' => $this->request->getPost('harga_satuan'),
            'total_harga' => $total_harga,
        ];

        // Simpan data ke tabel pembelian_barang
        $pembelianBarangModel->save($pembelianData);

        // Data untuk tabel pengeluaran_sekolah
        $pengeluaranData = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pengeluaran' => 'Pembelian Barang', // Menandakan jenis pengeluaran
            'jumlah_pengeluaran' => $total_harga, // Menggunakan total_harga sebagai jumlah pengeluaran
        ];

        // Simpan data ke tabel pengeluaran_sekolah
        $pengeluaranModel->save($pengeluaranData);

        // Redirect ke halaman pembelian_barang setelah data berhasil disimpan
        return redirect()->to('/pembelian_barang');
    }

    public function edit($id)
    {
        $model = new PembelianBarangModel();
        $data['pembelian_barang'] = $model->find($id);
        return view('pembelian_barang/edit', $data);
    }

    public function update($id)
    {
        $model = new PembelianBarangModel();
        $pengeluaranModel = new PengeluaranModel();
    
        $total_harga = $model->calculateTotalHarga($this->request->getPost('jumlah_barang'), $this->request->getPost('harga_satuan'));
    
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_barang' => $this->request->getPost('nama_barang'),
            'jumlah_barang' => $this->request->getPost('jumlah_barang'),
            'harga_satuan' => $this->request->getPost('harga_satuan'),
            'total_harga' => $total_harga,
        ];
    
        // Update pembelian_barang
        $model->update($id, $data);
    
        // Update pengeluaran_sekolah
        $pengeluaranData = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pengeluaran' => 'Pembelian Barang',
            'jumlah_pengeluaran' => $total_harga,
        ];
    
        // Update pengeluaran jika id pengeluaran ditemukan berdasarkan id pembelian
        $pengeluaranModel->update($id, $pengeluaranData);
    
        return redirect()->to('/pembelian_barang');
    }
    

    public function delete($id)
    {
        $model = new PembelianBarangModel();
        $model->delete($id);
        return redirect()->to('/pembelian_barang');
    }
}
