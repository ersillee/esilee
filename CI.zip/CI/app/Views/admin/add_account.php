<!DOCTYPE html>
<html>
<head>
    <title>Tambah Akun</title>
</head>
<body>
    <h2>Tambah Akun Baru</h2>

    <?php if (session()->getFlashdata('success')): ?>
        <p><?= session()->getFlashdata('success'); ?></p>
    <?php endif; ?>

    <?php if (session()->getFlashdata('errors')): ?>
        <ul>
            <?php foreach (session()->getFlashdata('errors') as $error): ?>
                <li><?= esc($error) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <form action="<?= site_url('admin/add-account') ?>" method="post">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required><br>

        <label for="role">Role:</label>
        <select name="role" id="role" required>
            <option value="admin">Admin</option>
            <option value="bendahara">Bendahara</option>
            <option value="kepala sekolah">Kepala Sekolah</option>
        </select><br>

        <button type="submit">Tambah Akun</button>
    </form>
</body>
</html>
