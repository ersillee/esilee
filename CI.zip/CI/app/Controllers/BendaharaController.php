<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class BendaharaController extends Controller
{
    public function __construct()
    {
        // Memeriksa apakah pengguna adalah bendahara
        if (session()->get('role') !== 'bendahara') {
            return redirect()->to('/home'); // Arahkan ke home jika bukan bendahara
        }
    }

    public function index()
    {
        return view('bendahara/index');
    }

    // Tambahkan metode lainnya di sini
}
