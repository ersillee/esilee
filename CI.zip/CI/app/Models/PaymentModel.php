<?php

namespace App\Models;

use CodeIgniter\Model;

class PaymentModel extends Model
{
    protected $table = 'payments'; // Ganti dengan nama tabel yang sesuai
    protected $primaryKey = 'id'; // Ganti dengan kunci utama yang sesuai
    protected $allowedFields = ['id_siswa', 'id_transaksi', 'periode_bulan', 'periode_tahun', 'amount', 'tanggal_pembayaran'];
}
