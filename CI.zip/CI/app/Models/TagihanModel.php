<?php

namespace App\Models;

use CodeIgniter\Model;

class TagihanModel extends Model
{
    protected $table = 'tagihan';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'jenis_tagihan', 'jumlah'];

    public function getTotalPengeluaranBulanIni()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }

    // Tambahkan metode untuk menghitung total pengeluaran seluruhnya
    public function getTotalPengeluaranSeluruhnya()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
