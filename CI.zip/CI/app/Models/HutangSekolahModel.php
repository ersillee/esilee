<?php

namespace App\Models;

use CodeIgniter\Model;

class HutangSekolahModel extends Model
{
    protected $table = 'hutang_sekolah';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'pemberi_hutang', 'jumlah_hutang', 'dibayar', 'tanggal_jatuh_tempo'];

    public function getTotalPengeluaranBulanIni()
    {
        return $this->selectSum('dibayar') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }
    public function getTotalPengeluaranSeluruhnya()
    {
        return $this->selectSum('dibayar') // Menggunakan selectSum untuk menghitung total
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
