$(document).on('click', '#btn-edit', function(){
    $('.modal-body #id-siswa').val($(this).data('id'));
    $('.modal-body #id-siswa').val($(this).data('payment'));
    $('.modal-body #id-siswa').val($(this).data('name'));
})