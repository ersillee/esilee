<?php

namespace App\Models;

use CodeIgniter\Model;

class DonaturModel extends Model
{
    protected $table = 'donatur';
    protected $primaryKey = 'id';
    protected $allowedFields = ['nama_donatur', 'kontak_donatur', 'jumlah_sumbangan', 'tanggal_sumbangan', 'keterangan'];
}
