<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Cicilan Pembayaran</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Edit Cicilan Pembayaran</h2>
    <form action="<?= base_url('cicilan_pembayaran/update/' . $cicilan['id']) ?>" method="post">
        <div class="form-group">
            <label>ID Siswa</label>
            <input type="number" name="id_siswa" class="form-control" value="<?= $cicilan['id_siswa'] ?>" required>
        </div>
        <div class="form-group">
            <label>Jumlah Cicilan</label>
            <input type="number" name="jumlah_cicilan" class="form-control" value="<?= $cicilan['jumlah_cicilan'] ?>" required>
        </div>
        <div class="form-group">
            <label>Tanggal Jatuh Tempo</label>
            <input type="date" name="tanggal_jatuh_tempo" class="form-control" value="<?= $cicilan['tanggal_jatuh_tempo'] ?>" required>
        </div>
        <div class="form-group">
            <label>Status</label>
            <select name="status" class="form-control" required>
                <option value="Belum Bayar" <?= ($cicilan['status'] == 'Belum Bayar') ? 'selected' : '' ?>>Belum Bayar</option>
                <option value="Lunas" <?= ($cicilan['status'] == 'Lunas') ? 'selected' : '' ?>>Lunas</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?= base_url('cicilan_pembayaran') ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>

</body>
</html>
