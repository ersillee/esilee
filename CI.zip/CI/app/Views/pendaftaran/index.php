<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Data Pendaftaran</h2>
    <div class="alert alert-info">
    Total Pemasukan Bulan Ini: <?= number_format($total_pemasukan, 2, ',', '.') ?> 
</div>

    <a href="/pendaftaran/create" class="btn btn-primary mb-3">Tambah Pendaftaran</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Nama Siswa</th>
                <th>Jumlah yang Harus Dibayar</th>
                <th>Jumlah yang Dibayar</th>
                <th>Balance</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pendaftaran as $p): ?>
                <tr>
                    <td><?= $p['tanggal'] ?></td>
                    <td><?= $p['nama'] ?></td>
                    <td><?= $p['nama_siswa'] ?></td>
                    <td><?= $p['jumlah_yang_harus_dibayar'] ?></td>
                    <td><?= $p['jumlah_yang_dibayar'] ?></td>
                    <td>
                        <?php 
                            $balance = $p['jumlah_yang_dibayar'] - $p['jumlah_yang_harus_dibayar'];
                            echo $balance;
                        ?>
                    </td>
                    <td>
                        <a href="/pendaftaran/edit/<?= $p['id'] ?>" class="btn btn-warning">Edit</a>
                        <a href="/pendaftaran/delete/<?= $p['id'] ?>" class="btn btn-danger" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
