<?php

namespace App\Models;

use CodeIgniter\Model;

class PengaturanSPPModel extends Model
{
    protected $table = 'pengaturan_spp';
    protected $primaryKey = 'id';
    protected $allowedFields = ['jumlah_spp', 'berlaku_mulai'];
}
