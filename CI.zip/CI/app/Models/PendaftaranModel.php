<?php

namespace App\Models;

use CodeIgniter\Model;

class PendaftaranModel extends Model
{
    protected $table = 'pendaftaran';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'tanggal', 'nama', 'nama_siswa', 'jumlah_yang_harus_dibayar', 'jumlah_yang_dibayar', 'balance'
    ];

    public function calculateBalance($jumlah_yang_harus_dibayar, $jumlah_yang_dibayar)
    {
        return $jumlah_yang_harus_dibayar - $jumlah_yang_dibayar;
    }

    public function getTotalPemasukanBulanIni()
    {
        return $this->selectSum('jumlah_yang_dibayar') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
