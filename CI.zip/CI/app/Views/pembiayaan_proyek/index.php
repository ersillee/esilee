<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Data Pembiayaan Proyek</h2>
    <div class="alert alert-info">
        Total Pengeluaran Bulan Ini: <?= number_format($total_pengeluaran_bulan_ini, 2, ',', '.') ?> 
    </div>
    <div class="alert alert-info">
        Total Pengeluaran: <?= number_format($total_pengeluaran_seluruhnya, 2, ',', '.') ?>
    </div>
    <a href="/pembiayaan_proyek/create" class="btn btn-primary mb-3">Tambah Pembiayaan Proyek</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Nama Proyek</th>
                <th>Anggaran Total</th>
                <th>Anggaran Terpakai</th>
                <th>Sisa Anggaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pembiayaan_proyek as $item): ?>
                <tr>
                    <td><?= $item['id'] ?></td>
                    <td><?= $item['tanggal'] ?></td>
                    <td><?= $item['nama'] ?></td>
                    <td><?= $item['nama_proyek'] ?></td>
                    <td><?= $item['anggaran_total'] ?></td>
                    <td><?= $item['anggaran_terpakai'] ?></td>
                    <td><?= $item['sisa_anggaran'] ?></td>
                    <td>
                        <a href="/pembiayaan_proyek/edit/<?= $item['id'] ?>" class="btn btn-warning">Edit</a>
                        <form action="/pembiayaan_proyek/delete/<?= $item['id'] ?>" method="post" style="display:inline;">
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
