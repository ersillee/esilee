<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Pengeluaran Beasiswa</h2>
    <form action="/beasiswa/update/<?= $beasiswa['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $beasiswa['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama_siswa">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $beasiswa['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama_siswa">Nama Siswa</label>
            <input type="text" class="form-control" id="nama_siswa" name="nama_siswa" value="<?= $beasiswa['nama_siswa'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jenis_beasiswa">Jenis Beasiswa</label>
            <select class="form-control" id="jenis_beasiswa" name="jenis_beasiswa" required>
                <option value="Beasiswa Akademik" <?= ($beasiswa['jenis_beasiswa'] == 'Beasiswa Akademik') ? 'selected' : '' ?>>Beasiswa Akademik</option>
                <option value="Beasiswa Prestasi" <?= ($beasiswa['jenis_beasiswa'] == 'Beasiswa Prestasi') ? 'selected' : '' ?>>Beasiswa Prestasi</option>
                <option value="Beasiswa Sosial" <?= ($beasiswa['jenis_beasiswa'] == 'Beasiswa Sosial') ? 'selected' : '' ?>>Beasiswa Sosial</option>
                <option value="Beasiswa Olahraga" <?= ($beasiswa['jenis_beasiswa'] == 'Beasiswa Olahraga') ? 'selected' : '' ?>>Beasiswa Olahraga</option>
            </select>
        </div>
        <div class="form-group">
            <label for="jumlah_beasiswa">Jumlah Beasiswa</label>
            <input type="number" class="form-control" id="jumlah_beasiswa" name="jumlah_beasiswa" value="<?= $beasiswa['jumlah_beasiswa'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
