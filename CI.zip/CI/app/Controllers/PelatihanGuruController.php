<?php

namespace App\Controllers;

use App\Models\PelatihanGuruModel;
use App\Models\PengeluaranModel;

class PelatihanGuruController extends BaseController
{
    public function index()
    {
        $model = new PelatihanGuruModel();
        $data['pelatihan_guru'] = $model->findAll();
        $totalBulanIni = $model->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni ? $totalBulanIni['jumlah'] : 0;

        $totalSeluruhnya = $model->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya ? $totalSeluruhnya['jumlah'] : 0;
        return view('pelatihan_guru/index', $data);
    }

    public function create()
    {
        return view('pelatihan_guru/create');
    }

    public function store()
    {
        $pelatihanModel = new PelatihanGuruModel();
        $pengeluaranModel = new PengeluaranModel();

        // Mendapatkan data dari form
        $tanggal = $this->request->getPost('tanggal');
        $nama = $this->request->getPost('nama');
        $jenisPelatihan = $this->request->getPost('jenis_pelatihan');
        $jumlah = $this->request->getPost('jumlah');

        // Menyimpan data ke tabel pelatihan_guru
        $dataPelatihan = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jenis_pelatihan' => $jenisPelatihan,
            'jumlah' => $jumlah,
        ];
        $pelatihanModel->save($dataPelatihan);

        // Menyimpan data yang sama ke tabel pengeluaran_sekolah
        $dataPengeluaran = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jenis_pengeluaran' => 'Pelatihan Guru', // Anda bisa menyesuaikan jenis pengeluaran ini
            'jumlah_pengeluaran' => $jumlah,
        ];
        $pengeluaranModel->save($dataPengeluaran);

        return redirect()->to('/pelatihan_guru');
    }

    public function edit($id)
    {
        $model = new PelatihanGuruModel();
        $data['pelatihan'] = $model->find($id);
        return view('pelatihan_guru/edit', $data);
    }

    public function update($id)
    {
        $model = new PelatihanGuruModel();

        $data = [

            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pelatihan' => $this->request->getPost('jenis_pelatihan'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];

        $model->update($id, $data);
        return redirect()->to('/pelatihan_guru');
    }

    public function delete($id)
    {
        $model = new PelatihanGuruModel();
        $model->delete($id);
        return redirect()->to('/pelatihan_guru');
    }
}
