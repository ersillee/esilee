<?php

namespace App\Models;

use CodeIgniter\Model;

class LaporanKeuanganModel extends Model
{
    protected $table = 'laporan_keuangan'; // Nama tabel
    protected $primaryKey = 'id'; // Primary key
    protected $allowedFields = ['id_pengguna', 'bulan_laporan', 'total_pemasukan', 'total_pengeluaran', 'laporan_dibuat_pada']; // Kolom yang dapat diisi

    // Metode untuk mendapatkan data berdasarkan ID
    public function getDataById($id)
    {
        return $this->where('id', $id)->first(); // Mengambil satu baris berdasarkan ID
    }

    // Metode untuk mendapatkan semua data
    public function getAllData()
    {
        return $this->findAll(); // Mengambil semua data
    }
}
