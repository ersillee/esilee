<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kas Sekolah</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Kas Sekolah</h2>
        <form action="<?= site_url('kas_sekolah/update/' . $kas['id']) ?>" method="post">
            <div class="form-group">
                <label>Saldo Awal</label>
                <input type="number" name="saldo_awal" class="form-control" value="<?= $kas['saldo_awal'] ?>" required>
            </div>
            <div class="form-group">
                <label>Saldo Akhir</label>
                <input type="number" name="saldo_akhir" class="form-control" value="<?= $kas['saldo_akhir'] ?>" required>
            </div>
            <div class="form-group">
                <label>Keterangan</label>
                <input type="text" name="keterangan" class="form-control" value="<?= $kas['keterangan'] ?>" required>
            </div>
            <button type="submit" class="btn btn-warning">Update</button>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
