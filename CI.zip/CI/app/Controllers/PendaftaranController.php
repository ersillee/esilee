<?php

namespace App\Controllers;

use App\Models\PendaftaranModel;
use App\Models\PemasukanModel; // Pastikan untuk menambahkan model ini
use CodeIgniter\Controller;

class PendaftaranController extends Controller
{

        // Menambahkan properti untuk model
    protected $pendaftaranModel;

        public function __construct()
        {
            // Inisialisasi model PendaftaranModel
            $this->pendaftaranModel = new PendaftaranModel();
            $this->pemasukanModel = new PemasukanModel();
        }
    
    public function index()
    {
        $model = new PendaftaranModel();
        $data['pendaftaran'] = $model->findAll();
        $total = $model->getTotalPemasukanBulanIni();
        $data['total_pemasukan'] = $total ? $total['jumlah_yang_dibayar'] : 0;
        return view('pendaftaran/index', $data);
    }

    public function create()
    {
        // Misalnya, jumlah yang harus dibayar dihitung di controller
        $jumlah_yang_harus_dibayar = 100000; // Contoh perhitungan atau nilai tetap
        return view('pendaftaran/create', ['jumlah_yang_harus_dibayar' => $jumlah_yang_harus_dibayar]);
    }
    

    public function store()
    {
        $jumlah_yang_dibayar = $this->request->getPost('jumlah_yang_dibayar');
        $jumlah_yang_harus_dibayar = 100000; // Ganti sesuai perhitungan Anda
        $balance = $this->pendaftaranModel->calculateBalance($jumlah_yang_harus_dibayar, $jumlah_yang_dibayar);
    
        // Simpan data pendaftaran
        $this->pendaftaranModel->save([
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'jumlah_yang_harus_dibayar' => $jumlah_yang_harus_dibayar,
            'jumlah_yang_dibayar' => $jumlah_yang_dibayar,
            'balance' => $balance,
        ]);
    
        // Simpan data ke tabel pemasukan_sekolah
        $this->pemasukanModel->save([
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pemasukan' => 'Biaya Pendaftaran',
            'jumlah_pemasukan' => $jumlah_yang_dibayar,
        ]);
    
        return redirect()->to('/pendaftaran')->with('success', 'Data pendaftaran berhasil disimpan!');
    }
    
    

    public function edit($id)
    {
        $data['pendaftaran'] = $this->pendaftaranModel->find($id);
    
        // Menambahkan jumlah yang harus dibayar untuk ditampilkan di form edit
        $data['jumlah_yang_harus_dibayar'] = $data['pendaftaran']['jumlah_yang_harus_dibayar'];
    
        return view('pendaftaran/edit', $data);
    }

    public function update($id)
    {
        $jumlah_yang_harus_dibayar = $this->request->getPost('jumlah_yang_harus_dibayar');
        $jumlah_yang_dibayar = $this->request->getPost('jumlah_yang_dibayar');

        // Hitung balance
        $balance = $this->pendaftaranModel->calculateBalance($jumlah_yang_harus_dibayar, $jumlah_yang_dibayar);

        // Update data pendaftaran
        $this->pendaftaranModel->update($id, [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'jumlah_yang_harus_dibayar' => $jumlah_yang_harus_dibayar,
            'jumlah_yang_dibayar' => $jumlah_yang_dibayar,
            'balance' => $balance,
        ]);

        return redirect()->to('/pendaftaran')->with('success', 'Data pendaftaran berhasil diupdate!');
    }

    public function delete($id)
    {
        $this->pendaftaranModel->delete($id);
        return redirect()->to('/pendaftaran')->with('success', 'Data pendaftaran berhasil dihapus!');
    }
}
