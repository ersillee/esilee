<?php

namespace App\Controllers;

use App\Models\PemasukanModel;
use App\Models\PengeluaranModel;

class FinancialReportController extends BaseController
{
    protected $pemasukanModel;
    protected $pengeluaranModel;

    public function __construct()
    {
        $this->pemasukanModel = new PemasukanModel();
        $this->pengeluaranModel = new PengeluaranModel();
    }

    public function index()
    {
        $tahun = date('Y');
        $data = [
            'saldo_bulanan' => $this->getSaldoBulanan($tahun)
        ];

        return view('financial_report', $data);
    }

    private function getSaldoBulanan($tahun)
    {
        $saldoBulanan = [];
        $saldoAwal = 0;
    
        for ($bulan = 1; $bulan <= 12; $bulan++) {
            $pemasukan = $this->pemasukanModel->totalPemasukanPerBulan($bulan, $tahun);
            $pengeluaran = $this->pengeluaranModel->totalPengeluaranPerBulan($bulan, $tahun);
            
            // Cek jika pemasukan dan pengeluaran adalah angka
            if (!is_numeric($pemasukan)) {
                $pemasukan = 0; // Jika bukan angka, set ke 0
            }
            
            if (!is_numeric($pengeluaran)) {
                $pengeluaran = 0; // Jika bukan angka, set ke 0
            }
    
            // Hitung saldo akhir bulan ini
            $saldoAkhir = $saldoAwal + $pemasukan - $pengeluaran;
    
            // Simpan saldo awal dan saldo akhir ke dalam array
            $saldoBulanan[$bulan] = [
                'bulan' => date('F', mktime(0, 0, 0, $bulan, 1)),
                'saldo_awal' => $saldoAwal,
                'saldo_akhir' => $saldoAkhir
            ];
    
            // Update saldo awal untuk bulan berikutnya
            $saldoAwal = $saldoAkhir;
        }
    
        return $saldoBulanan;
    }
    
    
}
