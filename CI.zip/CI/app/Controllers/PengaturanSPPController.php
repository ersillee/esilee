<?php

namespace App\Controllers;

use App\Models\PengaturanSPPModel;
use CodeIgniter\Controller;

class PengaturanSPPController extends Controller
{
    public function index()
    {
        $model = new PengaturanSPPModel();
        $data['pengaturan_spp'] = $model->findAll();
        return view('pengaturan_spp/index', $data);
    }

    public function create()
    {
        return view('pengaturan_spp/create');
    }

    public function store()
    {
        $model = new PengaturanSPPModel();
        $data = [
            'jumlah_spp' => $this->request->getPost('jumlah_spp'),
            'berlaku_mulai' => $this->request->getPost('berlaku_mulai'),
        ];

        $model->insert($data);
        return redirect()->to('/pengaturan-spp');
    }
}
