<?php 
$role = $role ?? session()->get('role'); // Gunakan $role atau fallback ke session
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Keuangan Sekolah</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* Sidebar styling */
        #wrapper {
            display: flex;
        }

        #sidebar {
            width: 250px;
            background-color: #e3f2fd;
            min-height: 100vh;
            position: fixed;
        }

        #content-wrapper {
            margin-left: 250px;
            width: calc(100% - 250px);
            padding: 20px;
        }

        /* Topbar styling */
        .topbar {
            width: 100%;
            z-index: 1;
        }

        /* Dashboard card styling */
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .card {
            position: relative;
            display: flex;
            flex-direction: column;
            min-width: 0;
            word-wrap: break-word;
            background-color: #fff;
            background-clip: border-box;
            border: 1px solid #e3e6f0;
            padding: 20px;
            border-radius: 8px;
            color: #fff;
            font-weight: bold;
            text-align: center;
            height: 100px;
        }

        .green { background-color: #28a745; }
        .orange { background-color: #ffc107; }
        .red { background-color: #dc3545; }
        .blue { background-color: #007bff; }
    </style>
</head>
<body>
<div id="wrapper">
    <!-- Sidebar -->
    <div id="sidebar">
        <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url(); ?>">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-school" style="color: #0d47a1;"></i>
                </div>
                <div class="sidebar-brand-text mx-3" style="color: #0d47a1;">SMK Advent Tongute Goin</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('home'); ?>" style="color: #1e2a3d;">
                    <i class="fas fa-fw fa-tachometer-alt" style="color: #0d47a1;"></i>
                    <span>Beranda</span>
                </a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider">

            <!-- Member Section -->
            <div class="sidebar-heading" style="color: #0d47a1;">
                Member
            </div>

            <?php if ($role == 'admin'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('laporan_keuangan'); ?>" style="color: #1e2a3d;">
                        <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
                        <span>Laporan Keuangan</span>
                    </a>
                </li>
            <?php elseif ($role == 'bendahara'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('laporan_keuangan'); ?>" style="color: #1e2a3d;">
                        <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
                        <span>Laporan Keuangan</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pemasukan/create'); ?>" style="color: #1e2a3d;">
                        <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
                        <span>Create Pemasukan</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('pengeluaran/create'); ?>" style="color: #1e2a3d;">
                        <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
                        <span>Create Pengeluaran</span>
                    </a>
                </li>
            <?php elseif ($role == 'kepala_sekolah'): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?= base_url('laporan_keuangan'); ?>" style="color: #1e2a3d;">
                        <i class="fas fa-chart-line" style="color: #0d47a1;"></i>
                        <span>Laporan Keuangan</span>
                    </a>
                </li>
            <?php endif; ?>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">
        </ul>
    </div>
    <!-- End of Sidebar -->



<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-dark bg-primary topbar mb-4 static-top shadow">

            <!-- Sidebar Toggle (Topbar) -->
            <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                <i class="fa fa-bars"></i>
            </button>

            <!-- Topbar Navbar -->
            <ul class="navbar-nav ml-auto d-flex align-items-center">

                <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                <li class="nav-item dropdown no-arrow d-sm-none">
                    <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                       data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-search fa-fw"></i>
                    </a>
                </li>
                <a href="/home" class="btn btn-secondary mr-auto ml-3" title="Kembali ke Home">
                <i class="fas fa-arrow-left"></i>
            </a>
            <a href="/laporan_keuangan" class="btn btn-secondary mr-auto ml-3" title="Halaman laporan keuangan">
                <i class="fas fa-file-invoice-dollar"></i>
            </a>

                <!-- Nav Item - Account Dropdown (Admin Only) -->
                <?php if ($role == 'admin'): ?>
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="accountDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="mr-2 d-none d-lg-inline text-white small"><?= ucfirst($role) ?> Account</span>
                        <i class="fas fa-cog text-white"></i>
                    </a>
                    <!-- Dropdown - Account Menu -->
                    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="accountDropdown">
                        <a class="dropdown-item" href="/register">
                            <i class="fas fa-user-plus fa-sm fa-fw mr-2 text-gray-400"></i> Add Account
                        </a>
                        <a class="dropdown-item" href="/admin/list_account">
                            <i class="fas fa-user-edit fa-sm fa-fw mr-2 text-gray-400"></i> Daftar Account
                        </a>
                        
                    </div>
                </li>
                <li class="nav-item">
                    <button class="btn btn-link text-white" style="margin-right: 20px;" onclick="window.location.href='/change_password'">
                        <i class="fas fa-lock" style="color: #FFD700;"></i> Change Password
                    </button>
                </li>
<!--                <li class="nav-item">
                    <button class="btn btn-link text-white" onclick="window.location.href='#'">
                        <i class="fas fa-user-circle" style="color: #FFFFFF;"></i> Profile
                    </button>
                </li>
                <?php endif; ?>

                <!-- Nav Item - Change Password & Profile (For Bendahara and Kepala Sekolah) -->
                <?php if ($role == 'bendahara' || $role == 'kepala_sekolah'): ?>
                <li class="nav-item">
                    <button class="btn btn-link text-white" style="margin-right: 20px;" onclick="window.location.href='/change_password'">
                        <i class="fas fa-lock" style="color: #FFD700;"></i> Change Password
                    </button>
                </li>
 <!--               <li class="nav-item">
                    <button class="btn btn-link text-white" onclick="window.location.href='#'">
                        <i class="fas fa-user-circle" style="color: #FFFFFF;"></i> Profile
                    </button>
                </li>
                <?php endif; ?>

                <div class="topbar-divider d-none d-sm-block"></div>

                <!-- Nav Item - User Information -->
                <li class="nav-item dropdown no-arrow">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown">
                        <span class="mr-2 d-none d-lg-inline text-white small">
                            <?= session()->get('role') ?? 'User' ?> <!-- Menampilkan peran atau default 'User' jika sesi tidak ada -->
                        </span>
                        <img class="img-profile rounded-circle" src="assets/img/profile/gambar.png" style="width: 30px; height: 30px;">
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                            <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i> Logout
                        </a>
                    </div>
                </li>

            </ul>

        </nav>
        <!-- End of Topbar -->




            <!-- Content goes here -->
            <div class="container-fluid">
                <?= $this->renderSection('content') ?>
            </div>
            <!-- End of Content -->
        </div>
        <!-- End of Main Content -->
    </div>
    <!-- End of Content Wrapper -->
</div>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
