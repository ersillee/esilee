<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Donatur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px;
            border: 1px solid #dddddd;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        a {
            text-decoration: none;
            color: blue;
        }
        a:hover {
            text-decoration: underline;
        }
        .button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            text-align: center;
            display: inline-block;
        }
        .button:hover {
            background-color: #45a049;
        }
        .total {
            font-weight: bold;
            font-size: 1.2em;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<h1>Daftar Donatur</h1>
<a class="button" href="/donatur/create">Tambah Donatur</a>

<?php
// Hitung total sumbangan
$totalSumbangan = 0;
foreach ($donatur as $d) {
    $totalSumbangan += $d['jumlah_sumbangan'];
}
?>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Nama Donatur</th>
            <th>Kontak Donatur</th>
            <th>Jumlah Sumbangan</th>
            <th>Tanggal Sumbangan</th>
            <th>Keterangan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($donatur as $d) : ?>
        <tr>
            <td><?= $d['id']; ?></td>
            <td><?= htmlspecialchars($d['nama_donatur']); ?></td>
            <td><?= htmlspecialchars($d['kontak_donatur']); ?></td>
            <td><?= number_format($d['jumlah_sumbangan'], 0, ',', '.'); ?></td>
            <td><?= date('d-m-Y', strtotime($d['tanggal_sumbangan'])); ?></td>
            <td><?= htmlspecialchars($d['keterangan']); ?></td>
            <td>
                <a href="/donatur/edit/<?= $d['id']; ?>">Edit</a> |
                <a href="/donatur/delete/<?= $d['id']; ?>" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">Hapus</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="total">
    Total Sumbangan: <?= number_format($totalSumbangan, 0, ',', '.'); ?>
</div>

</body>
</html>
