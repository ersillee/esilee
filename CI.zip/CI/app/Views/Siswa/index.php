<!-- View: app/Views/siswa/index.php -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= $judul; ?></h1>

    <?= session()->getFlashdata('message') ? '<div class="alert alert-success">' . session()->getFlashdata('message') . '</div>' : ''; ?>
    <?= session()->getFlashdata('err') ? '<div class="alert alert-danger">' . session()->getFlashdata('err') . '</div>' : ''; ?>

    <form action="<?= base_url('siswa'); ?>" method="GET">
        <input type="text" name="search" value="<?= isset($search) ? $search : ''; ?>" placeholder="Cari Siswa" />
        <button type="submit">Cari</button>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Pembayaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($siswa as $row): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><?= $row['name']; ?></td>
                    <td><?= $row['payment']; ?></td>
                    <td>
                        <a href="<?= base_url('siswa/hapus/' . $row['id']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?');">Hapus</a>
                        <a href="<?= base_url('siswa/edit/' . $row['id']); ?>" class="btn btn-warning btn-sm">Ubah</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
