<?php

namespace App\Controllers;

use App\Models\M_Transaksi;

class Transaksi extends BaseController
{
    protected $model;

    public function __construct()
    {
        $this->model = new M_Transaksi();
    }

    public function index()
    {
        $data = [
            'judul' => 'Data Transaksi',
            'transaksi' => $this->model->getAllData()
        ];
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar');  
        echo view('templates/v_topbar');
        echo view('transaksi/index', $data); // Pastikan Anda memiliki view ini
        echo view('templates/v_footer');
    }

    public function tambah()
    {
        if ($this->request->getMethod() === 'post') {
            $data = [
                'user_id' => $this->request->getPost('user_id'), // Pastikan ini ada di form
                'transaction_date' => $this->request->getPost('transaction_date'),
                'amount' => $this->request->getPost('amount'),
                'description' => $this->request->getPost('description'),
            ];

            $this->model->tambah($data);
            return redirect()->to('/transaksi'); // Redirect setelah menambah data
        }

        echo view('transaksi/tambah'); // Tampilkan form tambah transaksi
    }

    public function ubah($transaction_id)
    {
        $transaksi = $this->model->find($transaction_id);
        if (!$transaksi) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException("Transaksi dengan ID $transaction_id tidak ditemukan.");
        }

        if ($this->request->getMethod() === 'post') {
            $data = [
                'transaction_date' => $this->request->getPost('transaction_date'),
                'amount' => $this->request->getPost('amount'),
                'description' => $this->request->getPost('description'),
            ];

            $this->model->ubah($data, $transaction_id);
            return redirect()->to('/transaksi'); // Redirect setelah mengubah data
        }

        $data['transaksi'] = $transaksi;
        echo view('transaksi/ubah', $data); // Tampilkan form ubah transaksi
    }

    public function hapus($transaction_id)
    {
        $this->model->hapus($transaction_id);
        return redirect()->to('/transaksi'); // Redirect setelah menghapus data
    }
}
