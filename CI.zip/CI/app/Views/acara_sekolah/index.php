<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Data Acara Sekolah</h2>
    <div class="alert alert-info">
        Total Pengeluaran Bulan Ini: <?= number_format($total_pengeluaran_bulan_ini, 2, ',', '.') ?> 
    </div>
    <div class="alert alert-info">
        Total Pengeluaran: <?= number_format($total_pengeluaran_seluruhnya, 2, ',', '.') ?>
    </div>
    <a href="/acara_sekolah/create" class="btn btn-primary mb-3">Tambah Acara</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Jenis Acara</th>
                <th>Jumlah</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($acara_sekolah as $item): ?>
                <tr>
                    <td><?= $item['id'] ?></td>
                    <td><?= $item['tanggal'] ?></td>
                    <td><?= $item['nama'] ?></td>
                    <td><?= $item['jenis_acara'] ?></td>
                    <td><?= number_format($item['jumlah'], 2, ',', '.') ?></td>

                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
