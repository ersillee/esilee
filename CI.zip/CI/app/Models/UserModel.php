<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users'; // Ganti dengan nama tabel yang sesuai
    protected $primaryKey = 'id';
    protected $allowedFields = ['username', 'password', 'role']; // Kolom yang diizinkan untuk diisi
}
