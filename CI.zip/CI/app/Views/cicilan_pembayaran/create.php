<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Cicilan Pembayaran</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Tambah Cicilan Pembayaran</h2>
    <form action="<?= base_url('cicilan_pembayaran/store') ?>" method="post">
        <table class="table table-bordered">
            <tbody>
                <tr>
                    <td>
                        <div class="form-group">
                            <label>ID Siswa</label>
                            <input type="number" name="id_siswa" class="form-control" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="form-group">
                            <label>Jumlah Cicilan</label>
                            <input type="number" name="jumlah_cicilan" class="form-control" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="form-group">
                            <label>Tanggal Jatuh Tempo</label>
                            <input type="date" name="tanggal_jatuh_tempo" class="form-control" required>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status" class="form-control" required>
                                <option value="Belum Bayar">Belum Bayar</option>
                                <option value="Lunas">Lunas</option>
                            </select>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                        <a href="<?= base_url('cicilan_pembayaran') ?>" class="btn btn-secondary">Kembali</a>
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
</div>

</body>
</html>
