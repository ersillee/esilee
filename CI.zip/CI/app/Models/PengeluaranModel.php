<?php

namespace App\Models;

use CodeIgniter\Model;

class PengeluaranModel extends Model
{
    protected $table = 'pengeluaran_sekolah';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'jenis_pengeluaran', 'jumlah_pengeluaran', 'nama'];

    public function getByJenis($jenis = null)
    {
        if ($jenis) {
            return $this->where('jenis_pengeluaran', $jenis)->findAll();
        }
        return $this->findAll();
    }

    public function totalPengeluaranHarian($tanggal)
    {
        if (!$this->isValidDate($tanggal)) {
            return ['jumlah_pengeluaran' => 0];
        }

        return $this->selectSum('jumlah_pengeluaran')
                    ->where('DATE(tanggal)', $tanggal)
                    ->first() ?? ['jumlah_pengeluaran' => 0];
    }

    public function totalPengeluaranPerBulan($bulan, $tahun)
    {
        return $this->selectSum('jumlah_pengeluaran')
                    ->where('MONTH(tanggal)', $bulan)
                    ->where('YEAR(tanggal)', $tahun)
                    ->first() ?? ['jumlah_pengeluaran' => 0];
    }

}


