<!-- Views/admin/list_account.php -->
<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<h2>List of Accounts</h2>

<?php if (session()->getFlashdata('success')) : ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>
<?php if (session()->getFlashdata('error')) : ?>
    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Password</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($users as $user) : ?>
            <tr>
                <td><?= esc($user['id']) ?></td>
                <td><?= esc($user['username']) ?></td>
                <td><?= esc($user['password']) ?></td>
                <td><?= esc($user['role']) ?></td>
                <td>
                    <a href="<?= base_url('admin/updateAccount/' . $user['id']) ?>" class="btn btn-sm btn-primary">Edit</a>
                    <a href="<?= base_url('admin/deleteAccount/' . $user['id']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?= $this->endSection() ?>
