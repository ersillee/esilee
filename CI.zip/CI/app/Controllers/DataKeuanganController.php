<?php

namespace App\Controllers;

use App\Models\M_AuditKeuangan;
use App\Controllers\BaseController;

class AuditKeuangan extends BaseController
{
    protected $m_audit_keuangan;

    public function __construct()
    {
        $this->m_audit_keuangan = new M_AuditKeuangan();
    }

    // Fungsi untuk menampilkan semua data audit keuangan
    public function index()
    {
        try {
            // Ambil semua data audit keuangan dari model
            $data['audit_keuangan'] = $this->m_audit_keuangan->getAllData();

            // Jika data tidak ditemukan, kirim pesan ke view
            if (empty($data['audit_keuangan'])) {
                $data['message'] = "Tidak ada data audit keuangan.";
            }

            // Tampilkan view dengan data audit keuangan
            return view('audit_keuangan/index', $data);
        } catch (\Exception $e) {
            // Jika terjadi error saat mengambil data
            return redirect()->back()->with('error', 'Gagal mengambil data audit keuangan: ' . $e->getMessage());
        }
    }

    // Fungsi untuk menampilkan form tambah data audit keuangan
    public function create()
    {
        return view('audit_keuangan/create');
    }

    // Fungsi untuk menyimpan data audit keuangan
    public function store()
    {
        // Validasi input form
        if ($this->request->getMethod() === 'post') {
            // Ambil data dari input
            $data = [
                'tanggal_audit' => $this->request->getPost('tanggal_audit'),
                'auditor' => $this->request->getPost('auditor'),
                'laporan_audit' => $this->request->getPost('laporan_audit'),
                'rekomendasi' => $this->request->getPost('rekomendasi')
            ];

            // Simpan data ke database
            $result = $this->m_audit_keuangan->tambah($data);

            // Cek apakah data berhasil disimpan
            if ($result === true) {
                return redirect()->to('/audit_keuangan')->with('success', 'Data audit keuangan berhasil ditambahkan.');
            } else {
                // Tampilkan pesan kesalahan dari model
                return redirect()->back()->withInput()->with('error', 'Gagal menyimpan data audit keuangan: ' . implode(', ', $result));
            }
        }

        return redirect()->back()->withInput()->with('error', 'Permintaan tidak valid.');
    }

    // Fungsi untuk menampilkan form edit data audit keuangan
    public function edit($id)
    {
        // Ambil data audit keuangan berdasarkan ID
        $data['audit'] = $this->m_audit_keuangan->getDataById($id);
        
        if (empty($data['audit'])) {
            return redirect()->to('/audit_keuangan')->with('error', 'Data tidak ditemukan.');
        }

        return view('audit_keuangan/edit', $data);
    }

    // Fungsi untuk memperbarui data audit keuangan
    public function update($id)
    {
        if ($this->request->getMethod() === 'post') {
            $data = [
                'tanggal_audit' => $this->request->getPost('tanggal_audit'),
                'auditor' => $this->request->getPost('auditor'),
                'laporan_audit' => $this->request->getPost('laporan_audit'),
                'rekomendasi' => $this->request->getPost('rekomendasi')
            ];

            // Perbarui data di database
            $result = $this->m_audit_keuangan->updateData($id, $data);

            if ($result === true) {
                return redirect()->to('/audit_keuangan')->with('success', 'Data audit keuangan berhasil diperbarui.');
            } else {
                return redirect()->back()->withInput()->with('error', 'Gagal memperbarui data audit keuangan: ' . implode(', ', $result));
            }
        }

        return redirect()->back()->withInput()->with('error', 'Permintaan tidak valid.');
    }

    // Fungsi untuk menghapus data audit keuangan
    public function delete($id)
    {
        $result = $this->m_audit_keuangan->deleteData($id);

        if ($result === true) {
            return redirect()->to('/audit_keuangan')->with('success', 'Data audit keuangan berhasil dihapus.');
        } else {
            return redirect()->back()->with('error', 'Gagal menghapus data audit keuangan.');
        }
    }
}
