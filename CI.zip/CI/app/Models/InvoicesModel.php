<?php

namespace App\Models;

use CodeIgniter\Model;

class InvoicesModel extends Model
{
    protected $table = 'invoices';
    protected $primaryKey = 'invoice_id';
    protected $allowedFields = ['user_id', 'invoice_number', 'invoice_date', 'due_date', 'total_amount', 'status', 'created_at', 'updated_at'];
}
