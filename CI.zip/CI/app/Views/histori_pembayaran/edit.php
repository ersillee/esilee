<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Histori Pembayaran</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Edit Histori Pembayaran</h1>
        <form action="<?= site_url('histori_pembayaran/update/' . $histori['id']) ?>" method="post">
            <div class="form-group">
                <label for="id_siswa">ID Siswa:</label>
                <input type="number" id="id_siswa" name="id_siswa" class="form-control" value="<?= $histori['id_siswa'] ?>" required>
            </div>
            <div class="form-group">
                <label for="jumlah_pembayaran">Jumlah Pembayaran:</label>
                <input type="text" id="jumlah_pembayaran" name="jumlah_pembayaran" class="form-control" value="<?= $histori['jumlah_pembayaran'] ?>" required>
            </div>
            <div
