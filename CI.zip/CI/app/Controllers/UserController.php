<?php

namespace App\Controllers;

use App\Models\UserModel;

class UserController extends BaseController
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function index()
    {
        $data['users'] = $this->userModel->findAll();
        $data['judul'] = 'Daftar Pengguna';
        return view('user/index', $data);
    }

    public function create()
    {
        $data['judul'] = 'Tambah Pengguna';
        return view('user/create', $data);
    }

    public function store()
    {
        // Validasi input
        $this->validate([
            'username' => 'required|min_length[3]|max_length[20]|is_unique[users.username]',
            'password' => 'required|min_length[6]',
            'role' => 'required|in_list[admin,bendahara,kepala_sekolah]',
        ]);

        $data = [
            'username' => $this->request->getPost('username'),
            'password' => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'role' => $this->request->getPost('role'),
        ];

        $this->userModel->insert($data);
        return redirect()->to('/user');
    }

    public function edit($id)
    {
        $data['user'] = $this->userModel->find($id);
        $data['judul'] = 'Edit Pengguna';
        return view('user/edit', $data);
    }

    public function update($id)
    {
        // Validasi input
        $this->validate([
            'username' => 'required|min_length[3]|max_length[20]',
            'role' => 'required|in_list[admin,bendahara,kepala_sekolah]',
        ]);

        $data = [
            'username' => $this->request->getPost('username'),
            'role' => $this->request->getPost('role'),
        ];

        $password = $this->request->getPost('password');
        if ($password) {
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $this->userModel->update($id, $data);
        return redirect()->to('/user');
    }

    // Fungsi untuk mengganti kata sandi
    public function changePassword()
    {
        // Validasi input
        $this->validate([
            'new_password' => 'required|min_length[6]',
        ]);

        $newPassword = $this->request->getPost('new_password');
        $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

        // Simpan ke database
        $userId = session()->get('id'); // Pastikan ID pengguna diambil dari sesi
        $this->userModel->update($userId, ['password' => $hashedPassword]);

        return redirect()->to('/profile')->with('message', 'Password berhasil diperbarui.');
    }
}
