<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cicilan Pembayaran</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">
    <h2>Cicilan Pembayaran</h2>
    <a href="<?= base_url('cicilan_pembayaran/create') ?>" class="btn btn-primary mb-3">Tambah Cicilan</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>ID Siswa</th>
                <th>Jumlah Cicilan</th>
                <th>Tanggal Jatuh Tempo</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cicilan as $row): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['id_siswa'] ?></td>
                    <td><?= $row['jumlah_cicilan'] ?></td>
                    <td><?= $row['tanggal_jatuh_tempo'] ?></td>
                    <td><?= $row['status'] ?></td>
                    <td>
                        <a href="<?= base_url('cicilan_pembayaran/edit/' . $row['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="<?= base_url('cicilan_pembayaran/delete/' . $row['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus?')">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

</body>
</html>
