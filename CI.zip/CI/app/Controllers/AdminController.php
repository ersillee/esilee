<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class AdminController extends Controller
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();

        // Memeriksa apakah pengguna adalah admin
        if (session()->get('role') !== 'admin') {
            return redirect()->to('/home'); // Arahkan ke home jika bukan admin
        }
    }

    // Tampilkan daftar akun
    public function listAccount()
    {
        $data['users'] = $this->userModel->findAll();
        return view('admin/list_account', $data);
    }

    public function updateAccount($id)
    {
        $user = $this->userModel->find($id);
    
        if (!$user) {
            return redirect()->to('/admin/list_account')->with('error', 'User not found');
        }
    
        if ($this->request->getMethod() === 'post') {
            // Ambil data yang diinput oleh user
            $data = [
                'username' => $this->request->getPost('username'),
                'password' => $this->request->getPost('password'),
                'role' => $this->request->getPost('role'),
            ];
    
            // Periksa apakah password kosong, jika kosong jangan diupdate
            if (empty($data['password'])) {
                unset($data['password']); // Jangan update password jika kosong
            } else {
                // Jika password diubah, hash password terlebih dahulu
                $data['password'] = password_hash($data['password'], PASSWORD_BCRYPT);
            }
    
            // Update data akun di database
            if ($this->userModel->update($id, $data)) {
                return redirect()->to('/admin/list_account')->with('success', 'Account updated successfully');
            } else {
                return redirect()->back()->with('error', 'Failed to update account');
            }
        }
    
        return view('admin/edit_account', ['user' => $user]);
    }
    

    public function deleteAccount($id)
    {
        $user = $this->userModel->find($id);

        if (!$user) {
            return redirect()->to('/admin/list_account')->with('error', 'User not found');
        }

        if ($this->request->getMethod() === 'post' && $this->request->getPost('confirm') === 'yes') {
            $this->userModel->delete($id);
            return redirect()->to('/admin/list_account')->with('success', 'Account deleted successfully');
        }

        return view('admin/delete_account', ['user' => $user]);
    }
}
