<?php

namespace App\Controllers;

use App\Models\HutangSekolahModel;
use App\Models\PengeluaranModel;

class HutangSekolahController extends BaseController
{
    public function index()
    {
        $model = new HutangSekolahModel();
        $data['hutang_sekolah'] = $model->findAll();
        // Mendapatkan total pengeluaran bulan ini
        $totalBulanIni = $model->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni ? $totalBulanIni['dibayar'] : 0;

        // Mendapatkan total pengeluaran seluruhnya
        $totalSeluruhnya = $model->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya ? $totalSeluruhnya['dibayar'] : 0;
        return view('hutang_sekolah/index', $data);
    }

    public function create()
    {
        return view('hutang_sekolah/create');
    }

    public function store()
    {
        $hutangSekolahModel = new HutangSekolahModel();
        $pengeluaranModel = new PengeluaranModel();

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'pemberi_hutang' => $this->request->getPost('pemberi_hutang'),
            'jumlah_hutang' => $this->request->getPost('jumlah_hutang'),
            'dibayar' => $this->request->getPost('dibayar'),
            'tanggal_jatuh_tempo' => $this->request->getPost('tanggal_jatuh_tempo'),
        ];

        // Validasi input untuk 'dibayar'
        if (empty($data['dibayar'])) {
            return redirect()->back()->with('error', 'Kolom dibayar tidak boleh kosong!');
        }

        // Simpan data hutang sekolah
        $hutangSekolahModel->save($data);
        $hutangSekolahId = $hutangSekolahModel->getInsertID();

        // Simpan data pengeluaran sekolah
        $pengeluaranData = [
            'tanggal' => $data['tanggal'],
            'nama' => $data['nama'],
            'jenis_pengeluaran' => 'Hutang Sekolah',
            'jumlah_pengeluaran' => $data['dibayar'],
        ];
        $pengeluaranModel->save($pengeluaranData);

        return redirect()->to('/hutang_sekolah')->with('success', 'Data hutang sekolah berhasil disimpan!');
    }

    public function edit($id)
    {
        $model = new HutangSekolahModel();
        $data['hutang_sekolah'] = $model->find($id);
        return view('hutang_sekolah/edit', $data);
    }

    public function update($id)
    {
        $model = new HutangSekolahModel();

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'pemberi_hutang' => $this->request->getPost('pemberi_hutang'),
            'jumlah_hutang' => $this->request->getPost('jumlah_hutang'),
            'dibayar' => $this->request->getPost('dibayar'),
            'tanggal_jatuh_tempo' => $this->request->getPost('tanggal_jatuh_tempo'),
        ];

        // Validasi input untuk 'dibayar'
        if (empty($data['dibayar'])) {
            return redirect()->back()->with('error', 'Kolom dibayar tidak boleh kosong!');
        }

        // Update data jika semua valid
        $model->update($id, $data);
        return redirect()->to('/hutang_sekolah')->with('success', 'Data hutang sekolah berhasil diupdate!');
    }

    public function delete($id)
    {
        $model = new HutangSekolahModel();
        $model->delete($id);
        return redirect()->to('/hutang_sekolah')->with('success', 'Data hutang sekolah berhasil dihapus!');
    }
}
