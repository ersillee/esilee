<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Tambah Penggajian</h2>
    <form action="<?= base_url('penggajian/store') ?>" method="post">
        <div class="mb-3">
            <label for="tanggal" class="form-label">Tanggal</label>
            <input type="date" name="tanggal" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="nama_penerima" class="form-label">Nama Penerima</label>
            <input type="text" name="nama_penerima" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="jabatan" class="form-label">Jabatan</label>
            <select name="jabatan" class="form-control" required>
                <option value="guru">Guru</option>
                <option value="karyawan">Karyawan</option>
                <option value="staf">Staf</option>
            </select>
        </div>
        <div class="mb-3">
            <label for="jumlah_gaji" class="form-label">Jumlah Gaji</label>
            <input type="number" name="jumlah_gaji" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success mb-3">Simpan</button>
    </form>
</div>
<?= $this->endSection() ?>
