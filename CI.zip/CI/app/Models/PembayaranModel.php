<?php

namespace App\Models;

use CodeIgniter\Model;

class PembayaranModel extends Model
{
    protected $table = 'histori_pembayaran'; // Nama tabel di database
    protected $primaryKey = 'id'; // Primary key tabel
    protected $allowedFields = ['id_siswa', 'jumlah_pembayaran', 'metode_pembayaran', 'tanggal_pembayaran']; // Kolom yang diizinkan

    // Fungsi untuk mengambil semua data histori pembayaran
    public function getAllHistori()
    {
        return $this->findAll();
    }
}
